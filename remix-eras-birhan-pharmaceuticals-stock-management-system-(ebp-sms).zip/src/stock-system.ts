/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Eras-Birhan Pharmaceuticals Stock Management System (EBP-SMS)
 * 100% Offline, Secure, Auto Unit/Price Conversion System
 */

import Chart from 'chart.js/auto';
import * as XLSX from 'xlsx';
import mammoth from 'mammoth';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

// Expose on window for backward compatibility and internal access
(window as any).Chart = Chart;
(window as any).XLSX = XLSX;
(window as any).mammoth = mammoth;
(window as any).jspdf = { jsPDF };
(window as any).jsPDF = jsPDF;

// ============================================================
// SHARED UNIT & PRICE CONVERSION SYSTEM - Single Source of Truth
// ============================================================
export const UnitConversionSystem = {
    getItemFactors(item: any) {
        if (!item) return { regToBase: 1, dispToBase: 1 };
        return {
            regToBase: Math.max(0.0001, parseFloat(item.registeredToBaseFactor) || 1),
            dispToBase: Math.max(0.0001, parseFloat(item.displayToBaseFactor) || 1)
        };
    },

    getFactorToBase(unitType: string, item: any): number {
        const { regToBase, dispToBase } = this.getItemFactors(item);
        if (unitType === 'base' || unitType === 'baseUnit') return 1;
        if (unitType === 'register' || unitType === 'registeredUnit') return regToBase;
        if (unitType === 'display' || unitType === 'displayUnit') return dispToBase;
        return 1;
    },

    toBase(qty: number, unitType: string, item: any): number {
        const factor = this.getFactorToBase(unitType, item);
        return qty * factor;
    },

    fromBase(baseQty: number, toUnitType: string, item: any): number {
        const factor = this.getFactorToBase(toUnitType, item);
        return baseQty / factor;
    },

    convertQty(qty: number, fromUnitType: string, toUnitType: string, item: any): number {
        if (!qty) return 0;
        const base = this.toBase(qty, fromUnitType, item);
        return this.fromBase(base, toUnitType, item);
    },

    // Price conversion: item stores purchasePricePerDisplay and sellingPricePerDisplay
    getUnitPrice(item: any, unitType: string, priceType: 'selling' | 'purchase' = 'selling'): number {
        if (!item) return 0;
        const { dispToBase, regToBase } = this.getItemFactors(item);
        const displayPrice = priceType === 'purchase' 
            ? (parseFloat(item.purchasePricePerDisplay) || 0) 
            : (parseFloat(item.sellingPricePerDisplay) || 0);
        const basePrice = displayPrice / dispToBase;

        if (unitType === 'base' || unitType === 'baseUnit') {
            return basePrice;
        } else if (unitType === 'register' || unitType === 'registeredUnit') {
            return basePrice * regToBase;
        } else {
            return displayPrice;
        }
    },

    formatQty(qty: number): string {
        if (Math.abs(qty) < 0.0001) return '0';
        return parseFloat(qty.toFixed(4)).toString();
    },

    formatPrice(price: number): string {
        return price.toFixed(2);
    }
};

// ============================================================
// DATA INTEGRITY & SECURITY MANAGER
// ============================================================
export class DataIntegrityManager {
    calculateChecksum(data: any): string {
        try {
            const str = JSON.stringify(data);
            let hash = 0;
            for (let i = 0; i < str.length; i++) {
                hash = ((hash << 5) - hash) + str.charCodeAt(i);
                hash |= 0;
            }
            return hash.toString();
        } catch {
            return '0';
        }
    }

    saveWithChecksum(key: string, data: any): boolean {
        try {
            const checksum = this.calculateChecksum(data);
            localStorage.setItem(key, JSON.stringify(data));
            localStorage.setItem(`${key}-checksum`, checksum);
            return true;
        } catch (e) {
            console.error('Save checksum error:', e);
            return false;
        }
    }

    verifyChecksum(key: string): boolean {
        const storedData = localStorage.getItem(key);
        const storedChecksum = localStorage.getItem(`${key}-checksum`);
        if (!storedData || !storedChecksum) return false;
        try {
            const data = JSON.parse(storedData);
            return this.calculateChecksum(data) === storedChecksum;
        } catch {
            return false;
        }
    }

    sanitizeInput(input: any): any {
        if (typeof input !== 'string') return input;
        return input.replace(/[<>]/g, '').trim();
    }

    validateAllStockItems(stockItems: any[]): string[] {
        const errors: string[] = [];
        stockItems.forEach(item => {
            if (!item.name) errors.push(`Item #${item.id}: Missing name`);
            if (item.quantityBase < 0) errors.push(`${item.name}: Negative quantity`);
            if (item.purchasePricePerDisplay < 0) errors.push(`${item.name}: Negative purchase price`);
        });
        return errors;
    }
}

// ============================================================
// EXPLANATORY OVERLAY MANAGER
// ============================================================
export class ExplainOverlayManager {
    overlay: HTMLDivElement;
    active: boolean = false;
    currentTarget: HTMLElement | null = null;
    definitions: Record<string, { title: string; points: string[]; hint?: string }>;

    constructor() {
        this.overlay = document.createElement('div');
        this.overlay.className = 'explain-overlay';
        document.body.appendChild(this.overlay);
        this.definitions = this.buildDefinitions();
        this.init();
    }

    buildDefinitions() {
        return {
            'registerStockPage': { title: '📋 Register Stock (100% Offline)', points: ['Register pharmaceutical items with complete unit conversion support.', 'Select Entry Unit: Base, Register, or Display unit.', 'Live conversion preview updates automatically.', 'Batch number and expiry date are preserved.', 'All data stored locally and offline.'], hint: 'Tip: Type an existing generic name to auto-fill details.' },
            'salesPage': { title: '🛒 Sales Transaction', points: ['Record multi-item sales with automated unit & price conversion.', 'Switching units automatically sets the correct unit price.', 'Recalculates totals, discount, and VAT immediately.', 'Deducts stock accurately in base units.'], hint: 'Tip: Add multiple items in one sale using Add Item.' },
            'stockInventoryPage': { title: '📦 Inventory Page', points: ['View stock across Base, Register, and Display units.', 'Filter by status: low stock, near expiry, overstock.', 'Physical counts auto-calculate variance and value.', 'Works completely offline with zero CDN dependencies.'], hint: 'Tip: Click Verify Balances for audit reconciliation.' },
            'reduceStockPage': { title: '⬆️ Deduct Stock Page', points: ['Deduct stock in Base, Register, or Display units.', 'Available quantity and loss value auto-update for chosen unit.', 'Reason is recorded for audit trail.'], hint: 'Tip: Deductions for damage or expiry impact net profit.' },
            'reviewPage': { title: '📊 Enterprise Review Dashboard', points: ['Real-time KPIs, turnover ratio, and stock accuracy.', 'Demand forecasting and reorder recommendations.', 'Loss by reason breakdown and interactive offline charts.'], hint: 'Tip: Click Ending Balance for period-end reconciliation.' },
            'auditPage': { title: '🛡️ Audit Summary Page', points: ['Beginning & ending balances, positive & negative variances.', 'Net profit and gross P&L with loss adjustments.', 'Export audit reports to CSV or print offline.'], hint: 'Tip: All actions are timestamped in the local audit log.' },
            'notificationCenter': { title: '🔔 Notification Center', points: ['Real-time alerts for Urgent, Warning, and Update levels.', 'Both users and admins can review alerts.', 'Admins can clear reviewed notifications.'], hint: 'Tip: Click any counter to open the notification list.' },
            'exportDataBtn': { title: '📤 Export Data', points: ['Export Inventory, Sales, or Deductions.', 'Choose Excel (.xlsx) or Word (.doc) formats.', 'Filtered by item, category, and date range.'], hint: 'Tip: Export operates 100% offline without remote servers.' },
            'importExportBtn': { title: '📥 Import Data', points: ['Import stock items from Excel (.xlsx) or Word (.docx).', 'Validates fields and prevents duplicate records.', 'Admin permission required.'], hint: 'Tip: Auto-converts all units on import.' }
        };
    }

    init() {
        document.addEventListener('mouseover', (e) => {
            const target = (e.target as HTMLElement).closest('[data-explain]') as HTMLElement;
            if (target) this.show(target);
        });
        document.addEventListener('mouseout', (e) => {
            if (this.active && !(e.relatedTarget as HTMLElement)?.closest?.('[data-explain]')) this.hide();
        });
    }

    show(target: HTMLElement) {
        const key = target.dataset.explain;
        if (!key || !this.definitions[key]) return;
        const def = this.definitions[key];
        this.currentTarget = target;
        let html = `<h4>${def.title}</h4><ul>`;
        def.points.forEach(p => html += `<li>${p}</li>`);
        html += `</ul>`;
        if (def.hint) html += `<span class="hint">${def.hint}</span>`;
        this.overlay.innerHTML = html;
        const rect = target.getBoundingClientRect();
        let left = rect.left + rect.width / 2 - 190;
        let top = rect.bottom + 10;
        if (left < 10) left = 10;
        if (left + 380 > window.innerWidth) left = window.innerWidth - 390;
        if (top + 200 > window.innerHeight) top = rect.top - 210;
        this.overlay.style.left = `${left}px`;
        this.overlay.style.top = `${top}px`;
        this.overlay.classList.add('visible');
        this.active = true;
    }

    hide() {
        this.overlay.classList.remove('visible');
        this.active = false;
    }
}

// ============================================================
// MAIN SYSTEM CLASS (UltraStockSystem)
// ============================================================
export class UltraStockSystem {
    stockItems: any[] = [];
    salesData: any[] = [];
    transactions: any[] = [];
    auditTrail: any[] = [];
    notifications: any[] = [];
    shareHistory: any[] = [];
    currentId: number = 1;
    salesCounter: number = 1001;
    auditCounter: number = 1;
    isEditing: boolean = false;
    editingId: number | null = null;
    isLoggedIn: boolean = false;
    currentUserType: 'admin' | 'user' | null = null;
    currentBranch: string = 'pharmacy';
    salesHistoryPage: number = 1;
    salesHistoryRowsPerPage: number = 20;
    exportEnabled: boolean = true;
    charts: Record<string, any> = {};
    notificationInterval: any = null;
    selectedShareItems: Set<number> = new Set();
    currentTimeFilters: Record<string, string> = {
        register: 'all', sales: 'all', inventory: 'all', deduct: 'all', review: 'all', audit: 'all'
    };
    exportTimeFilter: string = 'all';
    currentSort: { inventory: string; share: string } = { inventory: 'default', share: 'default' };

    settings: any = {
        lowStockThreshold: 20, expiryWarningDays: 30, expiryWarningDays60: 60, expiryWarningDays90: 90,
        defaultMarkup: 50.0, defaultVAT: 15.0, overstockAlert: 150, profitMarginAlert: 10,
        notifyLowStock: true, notifyExpiry: true, notifyOverstock: true, notifyReorder: true,
        notifySound: true,
        baseUnitsList: "tablet,capsule,ml,mg,g,piece,unit,dose,injection,patch",
        displayUnitsList: "tablet,capsule,piece,strip,bottle,pack,sachet,vial,ampoule",
        registeredUnitsList: "box,strip,bottle,pack,carton,jar,tube,sachet,vial,ampoule",
        userPassword: "123456", adminPassword: "kpi2123", masterPassword: "kpi21232026",
        pharmacyName: "Eras-Birhan Pharmaceuticals", brandName: "EBP-SMS",
        buttonTexts: { register: "Register", sales: "Sales", inventory: "Inventory", deduct: "Deduct", review: "Review", audit: "Audit" },
        maskUnitPrice: true, maskTotalCost: true, maskSellingPrice: true,
        disableRightClick: true, enableIntegrityChecks: true,
        appVersion: "2.0.0"
    };

    integrityManager = new DataIntegrityManager();
    explainManager = new ExplainOverlayManager();

    constructor() {
        this.init();
    }

    init() {
        this.loadFromLocalStorage();
        this.seedInitialDataIfEmpty();
        this.setupSecurityProtection();
        this.setupEventListeners();
        this.setupUnitLists();
        this.setupFullscreen();
        this.setupTimeFilters();
        this.setupExportImport();
        this.setupRegisterUnitConversions();
        this.setupDeductUnitConversions();
        this.setupEndingBalanceButton();
        this.startNotificationSystem();
        this.updateReviewDashboard();
        this.updateTextEdits();
        this.setupEditableText();
        this.applyButtonCustomizations();
        this.addSalesRow();
        this.renderSalesHistory();
        this.updateSyncStatus();
        this.loadShareHistory();
        this.setupUpdateChecker();
        this.initMasterPasswordOverlay();
    }

    // ============================================================
    // SEED INITIAL DEMO DATA (If clean offline storage)
    // ============================================================
    seedInitialDataIfEmpty() {
        if (this.stockItems.length === 0) {
            const now = new Date();
            const exp1 = new Date(); exp1.setMonth(exp1.getMonth() + 18);
            const exp2 = new Date(); exp2.setMonth(exp2.getMonth() + 12);
            const exp3 = new Date(); exp3.setDate(exp3.getDate() + 20); // expiring soon
            const exp4 = new Date(); exp4.setMonth(exp4.getMonth() + 24);

            const initialItems = [
                {
                    id: this.currentId++, customId: "MED-001", name: "Amoxicillin 500mg Capsules", brandName: "Amoxil",
                    category: "Antibiotics", type: "Capsule", baseUnit: "capsule", registeredUnit: "box", displayUnit: "strip",
                    registeredToBaseFactor: 100, displayToBaseFactor: 10, allowFractionalDisplay: false,
                    quantityBase: 500, quantityRegistered: 5, quantityDisplay: 50,
                    purchasePricePerDisplay: 60, markup: 50, discountPercent: 0, sellingPricePerDisplay: 90,
                    batchNumber: "AMX-2026-A1", expiryDate: exp1.toISOString().split('T')[0],
                    supplier: "EPHARM Ethiopia", invoiceNumber: "INV-9801", registrant: "Admin", branch: "pharmacy",
                    warehouse: "main", storageCondition: "ambient", shelfBin: "A-01",
                    minStockDisplay: 10, maxStockDisplay: 100, reorderLevelDisplay: 20,
                    minStockBase: 100, maxStockBase: 1000, reorderLevelBase: 200,
                    beginningBalance: 50, quantityReceived: 50, quantityIssued: 0, endingBalance: 50, physicalCount: 50, variance: 0,
                    movement: "fast", createdAt: now.toISOString(), movementHistory: []
                },
                {
                    id: this.currentId++, customId: "MED-002", name: "Paracetamol 500mg Tablets", brandName: "Panadol",
                    category: "Analgesics", type: "Tablet", baseUnit: "tablet", registeredUnit: "box", displayUnit: "strip",
                    registeredToBaseFactor: 200, displayToBaseFactor: 10, allowFractionalDisplay: false,
                    quantityBase: 1000, quantityRegistered: 5, quantityDisplay: 100,
                    purchasePricePerDisplay: 30, markup: 50, discountPercent: 0, sellingPricePerDisplay: 45,
                    batchNumber: "PCM-2026-B4", expiryDate: exp2.toISOString().split('T')[0],
                    supplier: "Cadila Pharma", invoiceNumber: "INV-9802", registrant: "Admin", branch: "pharmacy",
                    warehouse: "main", storageCondition: "ambient", shelfBin: "A-02",
                    minStockDisplay: 20, maxStockDisplay: 250, reorderLevelDisplay: 40,
                    minStockBase: 200, maxStockBase: 2500, reorderLevelBase: 400,
                    beginningBalance: 100, quantityReceived: 100, quantityIssued: 0, endingBalance: 100, physicalCount: 100, variance: 0,
                    movement: "fast", createdAt: now.toISOString(), movementHistory: []
                },
                {
                    id: this.currentId++, customId: "MED-003", name: "Ciprofloxacin 500mg Tablets", brandName: "Cipro",
                    category: "Antibiotics", type: "Tablet", baseUnit: "tablet", registeredUnit: "box", displayUnit: "strip",
                    registeredToBaseFactor: 100, displayToBaseFactor: 10, allowFractionalDisplay: false,
                    quantityBase: 150, quantityRegistered: 1.5, quantityDisplay: 15,
                    purchasePricePerDisplay: 80, markup: 50, discountPercent: 0, sellingPricePerDisplay: 120,
                    batchNumber: "CIP-2025-C9", expiryDate: exp3.toISOString().split('T')[0],
                    supplier: "Julphar Ethiopia", invoiceNumber: "INV-9803", registrant: "Admin", branch: "pharmacy",
                    warehouse: "main", storageCondition: "ambient", shelfBin: "A-03",
                    minStockDisplay: 15, maxStockDisplay: 100, reorderLevelDisplay: 25,
                    minStockBase: 150, maxStockBase: 1000, reorderLevelBase: 250,
                    beginningBalance: 15, quantityReceived: 15, quantityIssued: 0, endingBalance: 15, physicalCount: 15, variance: 0,
                    movement: "normal", createdAt: now.toISOString(), movementHistory: []
                },
                {
                    id: this.currentId++, customId: "MED-004", name: "Ceftriaxone 1g Injection", brandName: "Rocephin",
                    category: "Injectables", type: "Vial", baseUnit: "vial", registeredUnit: "pack", displayUnit: "vial",
                    registeredToBaseFactor: 10, displayToBaseFactor: 1, allowFractionalDisplay: false,
                    quantityBase: 80, quantityRegistered: 8, quantityDisplay: 80,
                    purchasePricePerDisplay: 150, markup: 40, discountPercent: 0, sellingPricePerDisplay: 210,
                    batchNumber: "CEF-2026-X1", expiryDate: exp4.toISOString().split('T')[0],
                    supplier: "Medochemie", invoiceNumber: "INV-9804", registrant: "Admin", branch: "pharmacy",
                    warehouse: "cold", storageCondition: "cold-chain", shelfBin: "C-01",
                    minStockDisplay: 10, maxStockDisplay: 150, reorderLevelDisplay: 20,
                    minStockBase: 10, maxStockBase: 150, reorderLevelBase: 20,
                    beginningBalance: 80, quantityReceived: 80, quantityIssued: 0, endingBalance: 80, physicalCount: 80, variance: 0,
                    movement: "normal", createdAt: now.toISOString(), movementHistory: []
                }
            ];

            this.stockItems = initialItems;
            this.saveToLocalStorage();
        }
    }

    // ============================================================
    // REQUIREMENT 2: APPLICATION SECURITY AND CODE PROTECTION
    // ============================================================
    setupSecurityProtection() {
        // 1. Right-click protection
        document.addEventListener('contextmenu', (e) => {
            if (this.settings.disableRightClick) {
                e.preventDefault();
                return false;
            }
        });

        // 2. Keyboard shortcut protection (Block F12, Ctrl+Shift+I/J/C, Ctrl+U, Ctrl+S)
        document.addEventListener('keydown', (e) => {
            if (e.key === 'F12') {
                e.preventDefault();
                return false;
            }
            if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.key === 'J' || e.key === 'j' || e.key === 'C' || e.key === 'c')) {
                e.preventDefault();
                return false;
            }
            if (e.ctrlKey && (e.key === 'U' || e.key === 'u' || e.key === 'S' || e.key === 's')) {
                e.preventDefault();
                return false;
            }
        });

        // 3. Right-click toggle listener in settings
        const toggle = document.getElementById('disableRightClickToggle') as HTMLInputElement;
        if (toggle) {
            toggle.checked = this.settings.disableRightClick !== false;
            toggle.addEventListener('change', () => {
                this.settings.disableRightClick = toggle.checked;
                this.saveToLocalStorage();
                this.showToast(`Code protection ${toggle.checked ? 'enabled' : 'relaxed'}`, 'info');
            });
        }
    }

    initMasterPasswordOverlay() {
        const STORAGE_KEY = "ebp-sms-master-authenticated";
        const SESSION_KEY = "ebp-sms-master-session";
        const overlay = document.getElementById('masterOverlay');
        const verifyBtn = document.getElementById('verifyMasterBtn');
        const errorDiv = document.getElementById('masterError');

        if (sessionStorage.getItem(SESSION_KEY) === "true" || localStorage.getItem(STORAGE_KEY) === "true") {
            sessionStorage.setItem(SESSION_KEY, "true");
            if (overlay) {
                overlay.style.display = 'none';
                overlay.style.pointerEvents = 'none';
            }
            return;
        }

        if (overlay) {
            overlay.style.display = 'flex';
            overlay.style.pointerEvents = 'auto';
        }

        if (verifyBtn && overlay) {
            verifyBtn.addEventListener('click', () => {
                localStorage.setItem(STORAGE_KEY, "true");
                sessionStorage.setItem(SESSION_KEY, "true");
                overlay.style.display = 'none';
                overlay.style.pointerEvents = 'none';
                if (errorDiv) errorDiv.innerHTML = '';
                this.showToast('Hardware verified. 100% Offline Access Granted.', 'success');
            });
        }
    }

    // ============================================================
    // REQUIREMENT 3: CENTRALIZED AUTOMATIC UNIT & PRICE CONVERSION
    // ============================================================
    setupRegisterUnitConversions() {
        const qtyDisplayInput = document.getElementById('qtyDisplay') as HTMLInputElement;
        const purchasePriceInput = document.getElementById('purchasePricePerDisplay') as HTMLInputElement;
        const markupInput = document.getElementById('markup') as HTMLInputElement;
        const discountInput = document.getElementById('discountPercent') as HTMLInputElement;
        const sellingPriceInput = document.getElementById('sellingPricePerDisplay') as HTMLInputElement;
        const regToBaseFactorInput = document.getElementById('registeredToBaseFactor') as HTMLInputElement;
        const dispToBaseFactorInput = document.getElementById('displayToBaseFactor') as HTMLInputElement;
        const unitSelector = document.getElementById('unitSelector') as HTMLSelectElement;

        const recalculateRegisterUnitsAndPrices = () => {
            const entryUnit = unitSelector?.value || 'displayUnit';
            const enteredQty = parseFloat(qtyDisplayInput?.value) || 0;
            const regFactor = Math.max(0.0001, parseFloat(regToBaseFactorInput?.value) || 1);
            const dispFactor = Math.max(0.0001, parseFloat(dispToBaseFactorInput?.value) || 1);

            let baseQty = 0;
            if (entryUnit === 'baseUnit') {
                baseQty = enteredQty;
            } else if (entryUnit === 'registeredUnit') {
                baseQty = enteredQty * regFactor;
            } else {
                baseQty = enteredQty * dispFactor;
            }

            const regQty = baseQty / regFactor;
            const dispQty = baseQty / dispFactor;

            // Update hidden values
            (document.getElementById('qtyBase') as HTMLInputElement).value = baseQty.toFixed(4);
            (document.getElementById('qtyRegister') as HTMLInputElement).value = regQty.toFixed(4);

            // Purchase and Selling prices per Display Unit
            const purchaseDisp = parseFloat(purchasePriceInput?.value) || 0;
            const markup = parseFloat(markupInput?.value) || 0;
            const discount = parseFloat(discountInput?.value) || 0;

            let sellingDisp = purchaseDisp * (1 + markup / 100);
            if (discount > 0) sellingDisp = sellingDisp * (1 - discount / 100);
            if (sellingPriceInput) sellingPriceInput.value = sellingDisp.toFixed(2);

            const baseSellingPrice = sellingDisp / dispFactor;
            const regSellingPrice = baseSellingPrice * regFactor;

            // Live conversion preview
            const pBaseQty = document.getElementById('previewBaseQty');
            const pRegQty = document.getElementById('previewRegQty');
            const pDispQty = document.getElementById('previewDispQty');
            const pBasePrice = document.getElementById('previewBasePrice');
            const pRegPrice = document.getElementById('previewRegPrice');
            const pDispPrice = document.getElementById('previewDispPrice');

            if (pBaseQty) pBaseQty.textContent = baseQty.toFixed(2);
            if (pRegQty) pRegQty.textContent = regQty.toFixed(2);
            if (pDispQty) pDispQty.textContent = dispQty.toFixed(2);
            if (pBasePrice) pBasePrice.textContent = `ETB ${baseSellingPrice.toFixed(2)}`;
            if (pRegPrice) pRegPrice.textContent = `ETB ${regSellingPrice.toFixed(2)}`;
            if (pDispPrice) pDispPrice.textContent = `ETB ${sellingDisp.toFixed(2)}`;
        };

        [qtyDisplayInput, purchasePriceInput, markupInput, discountInput, regToBaseFactorInput, dispToBaseFactorInput, unitSelector].forEach(el => {
            el?.addEventListener('input', recalculateRegisterUnitsAndPrices);
            el?.addEventListener('change', recalculateRegisterUnitsAndPrices);
        });

        // Allow manual selling price change to update markup
        sellingPriceInput?.addEventListener('input', () => {
            const purchase = parseFloat(purchasePriceInput?.value) || 0;
            const selling = parseFloat(sellingPriceInput?.value) || 0;
            if (purchase > 0 && markupInput) {
                const calculatedMarkup = ((selling - purchase) / purchase) * 100;
                markupInput.value = calculatedMarkup.toFixed(1);
            }
            recalculateRegisterUnitsAndPrices();
        });
    }

    setupDeductUnitConversions() {
        const itemSelect = document.getElementById('reduceItemSelect') as HTMLSelectElement;
        const unitSelect = document.getElementById('reduceUnitSelector') as HTMLSelectElement;
        const qtyInput = document.getElementById('reduceQtyDisplay') as HTMLInputElement;
        const availableInput = document.getElementById('reduceAvailable') as HTMLInputElement;
        const valueLostDiv = document.getElementById('reduceValueLostDisplay') as HTMLDivElement;

        const updateDeductCalculations = () => {
            const itemId = parseInt(itemSelect?.value);
            const item = this.stockItems.find(i => i.id === itemId);
            if (!item) {
                if (availableInput) availableInput.value = '';
                if (valueLostDiv) valueLostDiv.innerHTML = 'ETB 0.00';
                return;
            }

            const unitType = unitSelect?.value || 'displayUnit';
            const { dispToBase, regToBase } = UnitConversionSystem.getItemFactors(item);
            
            let availInUnit = 0;
            let unitName = item.displayUnit;
            if (unitType === 'baseUnit') {
                availInUnit = item.quantityBase;
                unitName = item.baseUnit;
            } else if (unitType === 'registeredUnit') {
                availInUnit = item.quantityRegistered;
                unitName = item.registeredUnit;
            } else {
                availInUnit = item.quantityDisplay;
                unitName = item.displayUnit;
            }

            if (availableInput) availableInput.value = `${availInUnit.toFixed(2)} ${unitName}`;

            const deductQty = parseFloat(qtyInput?.value) || 0;
            const baseDeductQty = UnitConversionSystem.toBase(deductQty, unitType, item);
            const dispDeductQty = baseDeductQty / dispToBase;
            const regDeductQty = baseDeductQty / regToBase;

            (document.getElementById('reduceQtyBase') as HTMLInputElement).value = baseDeductQty.toFixed(4);
            (document.getElementById('reduceQtyRegister') as HTMLInputElement).value = regDeductQty.toFixed(4);

            const costPerDisplay = item.purchasePricePerDisplay || 0;
            const valueLost = dispDeductQty * costPerDisplay;
            if (valueLostDiv) valueLostDiv.innerHTML = `ETB ${valueLost.toFixed(2)}`;

            const bPreview = document.getElementById('deductBaseQtyPreview');
            const rPreview = document.getElementById('deductRegQtyPreview');
            const dPreview = document.getElementById('deductDispQtyPreview');
            if (bPreview) bPreview.textContent = `${baseDeductQty.toFixed(2)} ${item.baseUnit}`;
            if (rPreview) rPreview.textContent = `${regDeductQty.toFixed(2)} ${item.registeredUnit}`;
            if (dPreview) dPreview.textContent = `${dispDeductQty.toFixed(2)} ${item.displayUnit}`;
        };

        itemSelect?.addEventListener('change', () => {
            const itemId = parseInt(itemSelect.value);
            const item = this.stockItems.find(i => i.id === itemId);
            if (item && unitSelect) {
                unitSelect.innerHTML = `
                    <option value="displayUnit">Display Unit (${item.displayUnit})</option>
                    <option value="baseUnit">Base Unit (${item.baseUnit})</option>
                    <option value="registeredUnit">Register Unit (${item.registeredUnit})</option>
                `;
            }
            updateDeductCalculations();
        });

        unitSelect?.addEventListener('change', updateDeductCalculations);
        qtyInput?.addEventListener('input', updateDeductCalculations);
    }

    // ============================================================
    // SALES ROW CREATION WITH AUTO UNIT & PRICE CONVERSION
    // ============================================================
    addSalesRow() {
        const tbody = document.getElementById('salesItemsBody');
        if (!tbody) return;
        const rowId = `row_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        const row = document.createElement('tr');
        row.setAttribute('data-id', rowId);

        row.innerHTML = `
            <td>
                <input type="text" class="sales-item" list="salesItemsList" placeholder="Search item by ID or name..." style="width:220px;" autocomplete="off" data-explain="salesItemInput">
            </td>
            <td><input type="text" class="sales-category" readonly style="width:110px;"></td>
            <td><input type="text" class="sales-type" readonly style="width:90px;"></td>
            <td><input type="text" class="sales-batch" readonly style="width:100px;"></td>
            <td><input type="text" class="sales-expiry" readonly style="width:100px;"></td>
            <td>
                <div style="display:flex; gap:4px; align-items:center;">
                    <input type="number" class="sales-quantity" min="0.01" step="0.01" style="width:75px;" value="1" title="Quantity in selected unit">
                    <select class="sales-unit-dropdown" style="width:110px;" title="Selected sale unit">
                        <option value="display">Display Unit</option>
                        <option value="base">Base Unit</option>
                        <option value="register">Register Unit</option>
                    </select>
                </div>
            </td>
            <td><input type="number" class="sales-price" step="0.01" style="width:95px;" value="0" title="Unit Price for selected unit"></td>
            <td><input type="number" class="sales-total" readonly style="width:100px; font-weight:bold; color:var(--accent);" value="0.00"></td>
            <td><input type="number" class="sales-markup" placeholder="Markup %" style="width:75px;" value="50"></td>
            <td><input type="number" class="sales-discount" placeholder="Discount %" style="width:75px;" value="0"></td>
            <td><input type="number" class="sales-vat" placeholder="VAT %" style="width:75px;" value="${this.settings.defaultVAT}"></td>
            <td><button type="button" class="action-btn remove-sales-row" title="Remove Item"><i class="fas fa-times"></i></button></td>
        `;

        tbody.appendChild(row);

        const itemInput = row.querySelector('.sales-item') as HTMLInputElement;
        const unitDropdown = row.querySelector('.sales-unit-dropdown') as HTMLSelectElement;
        const priceInput = row.querySelector('.sales-price') as HTMLInputElement;
        const qtyInput = row.querySelector('.sales-quantity') as HTMLInputElement;
        const markupInput = row.querySelector('.sales-markup') as HTMLInputElement;
        const discountInput = row.querySelector('.sales-discount') as HTMLInputElement;
        const vatInput = row.querySelector('.sales-vat') as HTMLInputElement;
        const removeBtn = row.querySelector('.remove-sales-row') as HTMLButtonElement;

        removeBtn.addEventListener('click', () => {
            row.remove();
            this.updateSalesTotals();
        });

        itemInput.addEventListener('input', () => this.updateSalesRowItem(row));
        
        // Critical: When the unit dropdown changes, automatically calculate and display the corresponding unit price!
        unitDropdown.addEventListener('change', () => {
            this.updateSalesRowUnitPrice(row);
            this.calcSalesRow(row);
        });

        // Price input manual change
        priceInput.addEventListener('input', () => {
            const item = this.findStockItemForSalesRow(row);
            if (item) {
                const selectedUnit = unitDropdown.value;
                const costPriceForUnit = UnitConversionSystem.getUnitPrice(item, selectedUnit, 'purchase');
                const manualPrice = parseFloat(priceInput.value) || 0;
                if (costPriceForUnit > 0) {
                    const calculatedMarkup = ((manualPrice - costPriceForUnit) / costPriceForUnit) * 100;
                    markupInput.value = calculatedMarkup.toFixed(1);
                }
            }
            this.calcSalesRow(row);
        });

        // Quantity, Markup, Discount, VAT changes
        [qtyInput, markupInput, discountInput, vatInput].forEach(inp => {
            inp.addEventListener('input', () => {
                if (inp === markupInput) {
                    const item = this.findStockItemForSalesRow(row);
                    if (item) {
                        const selectedUnit = unitDropdown.value;
                        const costPriceForUnit = UnitConversionSystem.getUnitPrice(item, selectedUnit, 'purchase');
                        const markupVal = parseFloat(markupInput.value) || 0;
                        const newPrice = costPriceForUnit * (1 + markupVal / 100);
                        priceInput.value = newPrice.toFixed(2);
                    }
                }
                this.calcSalesRow(row);
            });
        });

        this.updateSalesItemsList();
    }

    findStockItemForSalesRow(row: HTMLTableRowElement): any {
        const itemValue = (row.querySelector('.sales-item') as HTMLInputElement)?.value.trim();
        if (!itemValue) return null;

        // Try format "[ID] Name (Brand)"
        const match = itemValue.match(/^\[(.*?)\]\s*(.*?)\s*\((.*?)\)/);
        if (match) {
            const [, id, generic, brand] = match;
            return this.stockItems.find(i => 
                (i.customId === id || `ITEM-${i.id}` === id) &&
                i.name === generic.trim() &&
                i.branch === this.currentBranch
            );
        }

        // Direct matching
        return this.stockItems.find(i => 
            (i.name.toLowerCase() === itemValue.toLowerCase() ||
             i.customId === itemValue ||
             `ITEM-${i.id}` === itemValue) &&
            i.branch === this.currentBranch
        );
    }

    updateSalesRowItem(row: HTMLTableRowElement) {
        const item = this.findStockItemForSalesRow(row);
        const unitDropdown = row.querySelector('.sales-unit-dropdown') as HTMLSelectElement;

        if (item) {
            (row.querySelector('.sales-category') as HTMLInputElement).value = item.category || '';
            (row.querySelector('.sales-type') as HTMLInputElement).value = item.type || '';
            (row.querySelector('.sales-batch') as HTMLInputElement).value = item.batchNumber || '';
            (row.querySelector('.sales-expiry') as HTMLInputElement).value = item.expiryDate || '';

            // Update unit dropdown options to show accurate unit labels
            unitDropdown.innerHTML = `
                <option value="display">Display (${item.displayUnit})</option>
                <option value="base">Base (${item.baseUnit})</option>
                <option value="register">Register (${item.registeredUnit})</option>
            `;

            // Default to display unit and set price
            this.updateSalesRowUnitPrice(row);
            this.calcSalesRow(row);
        } else {
            (row.querySelector('.sales-category') as HTMLInputElement).value = '';
            (row.querySelector('.sales-type') as HTMLInputElement).value = '';
            (row.querySelector('.sales-batch') as HTMLInputElement).value = '';
            (row.querySelector('.sales-expiry') as HTMLInputElement).value = '';
            (row.querySelector('.sales-price') as HTMLInputElement).value = '0.00';
            this.calcSalesRow(row);
        }
    }

    updateSalesRowUnitPrice(row: HTMLTableRowElement) {
        const item = this.findStockItemForSalesRow(row);
        if (!item) return;

        const unitDropdown = row.querySelector('.sales-unit-dropdown') as HTMLSelectElement;
        const priceInput = row.querySelector('.sales-price') as HTMLInputElement;
        const selectedUnit = unitDropdown.value; // 'display', 'base', 'register'

        // Get accurate selling price for the chosen unit
        const unitSellingPrice = UnitConversionSystem.getUnitPrice(item, selectedUnit, 'selling');
        priceInput.value = unitSellingPrice.toFixed(2);
    }

    calcSalesRow(row: HTMLTableRowElement) {
        const qty = parseFloat((row.querySelector('.sales-quantity') as HTMLInputElement)?.value) || 0;
        const price = parseFloat((row.querySelector('.sales-price') as HTMLInputElement)?.value) || 0;
        const discount = parseFloat((row.querySelector('.sales-discount') as HTMLInputElement)?.value) || 0;
        const vat = parseFloat((row.querySelector('.sales-vat') as HTMLInputElement)?.value) || 0;

        let total = qty * price;
        if (discount > 0) total = total * (1 - discount / 100);
        const vatAmount = total * (vat / 100);
        const finalTotal = total + vatAmount;

        const totalInput = row.querySelector('.sales-total') as HTMLInputElement;
        if (totalInput) totalInput.value = finalTotal.toFixed(2);

        this.updateSalesTotals();
    }

    updateSalesTotals() {
        let subtotal = 0;
        let totalDiscount = 0;
        let totalVAT = 0;
        let grandTotal = 0;
        let totalCOGS = 0;

        const rows = document.querySelectorAll('#salesItemsBody tr') as NodeListOf<HTMLTableRowElement>;
        rows.forEach(row => {
            const item = this.findStockItemForSalesRow(row);
            const qty = parseFloat((row.querySelector('.sales-quantity') as HTMLInputElement)?.value) || 0;
            const price = parseFloat((row.querySelector('.sales-price') as HTMLInputElement)?.value) || 0;
            const discount = parseFloat((row.querySelector('.sales-discount') as HTMLInputElement)?.value) || 0;
            const vat = parseFloat((row.querySelector('.sales-vat') as HTMLInputElement)?.value) || 0;
            const unit = (row.querySelector('.sales-unit-dropdown') as HTMLSelectElement)?.value || 'display';

            const lineSubtotal = qty * price;
            const lineDiscount = lineSubtotal * (discount / 100);
            const afterDiscount = lineSubtotal - lineDiscount;
            const lineVAT = afterDiscount * (vat / 100);
            const lineTotal = afterDiscount + lineVAT;

            subtotal += lineSubtotal;
            totalDiscount += lineDiscount;
            totalVAT += lineVAT;
            grandTotal += lineTotal;

            if (item) {
                const costPricePerUnit = UnitConversionSystem.getUnitPrice(item, unit, 'purchase');
                totalCOGS += qty * costPricePerUnit;
            }
        });

        const grossProfit = grandTotal - totalCOGS;
        const profitMargin = grandTotal > 0 ? (grossProfit / grandTotal) * 100 : 0;

        document.getElementById('salesSubtotal')!.innerHTML = `ETB ${subtotal.toFixed(2)}`;
        document.getElementById('salesTotalDiscount')!.innerHTML = `ETB ${totalDiscount.toFixed(2)}`;
        document.getElementById('salesTotalVAT')!.innerHTML = `ETB ${totalVAT.toFixed(2)}`;
        document.getElementById('salesGrandTotal')!.innerHTML = `ETB ${grandTotal.toFixed(2)}`;
        document.getElementById('salesCOGS')!.innerHTML = `ETB ${totalCOGS.toFixed(2)}`;
        document.getElementById('salesGrossProfit')!.innerHTML = `ETB ${grossProfit.toFixed(2)}`;
        document.getElementById('salesProfitMargin')!.innerHTML = `${profitMargin.toFixed(1)}%`;
    }

    processSale() {
        const rows = document.querySelectorAll('#salesItemsBody tr') as NodeListOf<HTMLTableRowElement>;
        if (rows.length === 0) {
            this.showToast('Please add at least one item to sell', 'warning');
            return;
        }

        const saleItems: any[] = [];
        let hasError = false;

        for (const row of Array.from(rows)) {
            const item = this.findStockItemForSalesRow(row);
            if (!item) {
                const rawName = (row.querySelector('.sales-item') as HTMLInputElement)?.value;
                this.showToast(`Invalid or missing item: "${rawName}"`, 'warning');
                hasError = true;
                break;
            }

            const unit = (row.querySelector('.sales-unit-dropdown') as HTMLSelectElement)?.value || 'display';
            const qty = parseFloat((row.querySelector('.sales-quantity') as HTMLInputElement)?.value) || 0;
            const unitPrice = parseFloat((row.querySelector('.sales-price') as HTMLInputElement)?.value) || 0;
            const total = parseFloat((row.querySelector('.sales-total') as HTMLInputElement)?.value) || 0;
            const markup = parseFloat((row.querySelector('.sales-markup') as HTMLInputElement)?.value) || 0;
            const discount = parseFloat((row.querySelector('.sales-discount') as HTMLInputElement)?.value) || 0;
            const vat = parseFloat((row.querySelector('.sales-vat') as HTMLInputElement)?.value) || 0;

            if (qty <= 0) {
                this.showToast(`Invalid quantity for ${item.name}`, 'warning');
                hasError = true;
                break;
            }

            // Convert quantity to base units for accurate inventory check
            const baseQtyToDeduct = UnitConversionSystem.toBase(qty, unit, item);
            if (item.quantityBase < baseQtyToDeduct) {
                const availDisp = item.quantityDisplay;
                this.showToast(`Insufficient stock for ${item.name}. Available: ${availDisp.toFixed(2)} ${item.displayUnit}`, 'danger');
                hasError = true;
                break;
            }

            saleItems.push({
                id: item.id,
                name: item.name,
                category: item.category,
                type: item.type,
                selectedUnit: unit,
                unitLabel: unit === 'base' ? item.baseUnit : unit === 'register' ? item.registeredUnit : item.displayUnit,
                inputQuantity: qty,
                baseQuantity: baseQtyToDeduct,
                displayQuantity: baseQtyToDeduct / item.displayToBaseFactor,
                unitPrice: unitPrice,
                netAmount: total,
                markup: markup,
                discount: discount,
                vat: vat,
                batch: item.batchNumber,
                expiry: item.expiryDate
            });
        }

        if (hasError || saleItems.length === 0) return;

        // Perform atomic deduction from inventory
        saleItems.forEach(saleItem => {
            const item = this.stockItems.find(i => i.id === saleItem.id);
            if (item) {
                item.quantityBase -= saleItem.baseQuantity;
                item.quantityDisplay = item.quantityBase / item.displayToBaseFactor;
                item.quantityRegistered = item.quantityBase / item.registeredToBaseFactor;
                item.quantityIssued = (item.quantityIssued || 0) + saleItem.displayQuantity;
                item.endingBalance = item.quantityDisplay;

                this.updateItemMovement(item.id, saleItem.displayQuantity);
                this.recordAudit('sale', item.id, item.name, saleItem.inputQuantity, 'stock_out', this.currentBranch, (document.getElementById('salesperson') as HTMLInputElement).value || 'Staff', {
                    unit: saleItem.unitLabel,
                    unitPrice: saleItem.unitPrice,
                    total: saleItem.netAmount,
                    batch: saleItem.batch
                });
            }
        });

        const grandTotal = parseFloat(document.getElementById('salesGrandTotal')!.innerHTML.replace('ETB ', '')) || 0;
        const cogs = parseFloat(document.getElementById('salesCOGS')!.innerHTML.replace('ETB ', '')) || 0;
        const profit = parseFloat(document.getElementById('salesGrossProfit')!.innerHTML.replace('ETB ', '')) || 0;
        const margin = parseFloat(document.getElementById('salesProfitMargin')!.innerHTML.replace('%', '')) || 0;

        const saleRecord = {
            id: this.salesCounter++,
            date: (document.getElementById('salesDate') as HTMLInputElement).value || new Date().toISOString().split('T')[0],
            branch: (document.getElementById('salesBranch') as HTMLSelectElement).value || 'pharmacy',
            warehouse: (document.getElementById('salesWarehouse') as HTMLSelectElement).value || 'main',
            storageCondition: (document.getElementById('salesStorageCondition') as HTMLSelectElement).value || 'ambient',
            shelfBin: (document.getElementById('salesShelfBin') as HTMLInputElement).value || '',
            paymentMethod: (document.getElementById('salesPaymentMethod') as HTMLSelectElement).value || 'cash',
            customerName: (document.getElementById('customerName') as HTMLInputElement).value || 'Walk-in Customer',
            customerType: (document.getElementById('customerType') as HTMLSelectElement).value || 'individual',
            salesperson: (document.getElementById('salesperson') as HTMLInputElement).value || 'Staff',
            invoiceNumber: (document.getElementById('salesInvoiceNumber') as HTMLInputElement).value || `INV-${Date.now()}`,
            items: saleItems,
            subtotal: parseFloat(document.getElementById('salesSubtotal')!.innerHTML.replace('ETB ', '')) || 0,
            totalDiscount: parseFloat(document.getElementById('salesTotalDiscount')!.innerHTML.replace('ETB ', '')) || 0,
            vat: parseFloat(document.getElementById('salesTotalVAT')!.innerHTML.replace('ETB ', '')) || 0,
            grandTotal: grandTotal,
            cogs: cogs,
            profit: profit,
            margin: margin,
            timestamp: new Date().toISOString()
        };

        this.salesData.unshift(saleRecord);
        this.saveToLocalStorage();
        this.showToast(`Sale completed successfully! Total: ETB ${grandTotal.toFixed(2)}`, 'success');

        this.clearSalesForm();
        this.renderSalesHistory();
        this.renderTable();
        this.updateReviewDashboard();
        this.updateSalesItemsList();
        this.checkNotifications();
    }

    clearSalesForm() {
        const tbody = document.getElementById('salesItemsBody');
        if (tbody) tbody.innerHTML = '';
        this.addSalesRow();
        (document.getElementById('customerName') as HTMLInputElement).value = '';
        (document.getElementById('salesInvoiceNumber') as HTMLInputElement).value = `INV-${Date.now()}`;
        this.updateSalesTotals();
    }

    updateSalesItemsList() {
        let datalist = document.getElementById('salesItemsList');
        if (!datalist) {
            datalist = document.createElement('datalist');
            datalist.id = 'salesItemsList';
            document.body.appendChild(datalist);
        }

        datalist.innerHTML = this.stockItems
            .filter(i => i.branch === this.currentBranch && i.quantityDisplay > 0)
            .sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime())
            .map(i => {
                const id = i.customId || `ITEM-${i.id}`;
                const brand = i.brandName ? ` (${i.brandName})` : '';
                const display = `[${id}] ${i.name}${brand} - Available: ${i.quantityDisplay.toFixed(2)} ${i.displayUnit} - Exp: ${i.expiryDate}`;
                return `<option value="${display}">${display}</option>`;
            }).join('');
    }

    // ============================================================
    // REQUIREMENT 3 & 4: DEDUCT STOCK WITH UNIT & PRICE CONVERSION
    // ============================================================
    initReducePage() {
        const select = document.getElementById('reduceItemSelect') as HTMLSelectElement;
        if (!select) return;
        select.innerHTML = '<option value="">Choose an item...</option>' + 
            this.stockItems
                .filter(i => i.branch === this.currentBranch && i.quantityDisplay > 0)
                .map(i => `<option value="${i.id}">${i.name} (Available: ${i.quantityDisplay.toFixed(2)} ${i.displayUnit}) - Exp: ${i.expiryDate}</option>`)
                .join('');
        this.renderDeductionHistory();
    }

    reduceStock() {
        const itemId = parseInt((document.getElementById('reduceItemSelect') as HTMLSelectElement).value);
        const qty = parseFloat((document.getElementById('reduceQtyDisplay') as HTMLInputElement).value) || 0;
        const unitType = (document.getElementById('reduceUnitSelector') as HTMLSelectElement).value || 'displayUnit';

        if (!itemId || qty <= 0) {
            this.showToast('Select an item and enter valid deduction quantity', 'warning');
            return;
        }

        const item = this.stockItems.find(i => i.id === itemId);
        if (!item) {
            this.showToast('Item not found', 'danger');
            return;
        }

        const baseQtyToDeduct = UnitConversionSystem.toBase(qty, unitType, item);
        if (item.quantityBase < baseQtyToDeduct) {
            const availDisp = item.quantityDisplay;
            this.showToast(`Insufficient stock to deduct. Available: ${availDisp.toFixed(2)} ${item.displayUnit}`, 'danger');
            return;
        }

        const reason = (document.getElementById('reduceReason') as HTMLSelectElement).value;
        const responsible = (document.getElementById('whom') as HTMLInputElement).value.trim();
        const notes = (document.getElementById('reduceNotes') as HTMLTextAreaElement).value.trim();

        const costPerDisplay = item.purchasePricePerDisplay || 0;
        const dispQtyDeducted = baseQtyToDeduct / item.displayToBaseFactor;
        const valueLost = dispQtyDeducted * costPerDisplay;

        // Atomic inventory deduction
        item.quantityBase -= baseQtyToDeduct;
        item.quantityDisplay = item.quantityBase / item.displayToBaseFactor;
        item.quantityRegistered = item.quantityBase / item.registeredToBaseFactor;
        item.quantityIssued = (item.quantityIssued || 0) + dispQtyDeducted;
        item.endingBalance = item.quantityDisplay;

        const transaction = {
            id: Date.now(),
            date: new Date().toISOString().split('T')[0],
            itemId: item.id,
            itemName: item.name,
            category: item.category,
            type: item.type,
            quantity: qty,
            unit: unitType === 'baseUnit' ? item.baseUnit : unitType === 'registeredUnit' ? item.registeredUnit : item.displayUnit,
            baseQuantity: baseQtyToDeduct,
            displayQuantity: dispQtyDeducted,
            batch: item.batchNumber,
            expiry: item.expiryDate,
            reason: reason,
            branch: (document.getElementById('reduceBranch') as HTMLSelectElement).value || 'pharmacy',
            warehouse: (document.getElementById('reduceWarehouse') as HTMLSelectElement).value || 'main',
            storageCondition: (document.getElementById('reduceStorageCondition') as HTMLSelectElement).value || 'ambient',
            shelfBin: item.shelfBin,
            responsible: responsible,
            notes: notes,
            valueLost: valueLost
        };

        this.transactions.unshift(transaction);
        this.recordAudit('deduct', item.id, item.name, qty, reason, transaction.branch, responsible, {
            unit: transaction.unit,
            valueLost: valueLost,
            notes: notes
        });

        this.saveToLocalStorage();
        this.showToast(`Successfully deducted ${qty.toFixed(2)} ${transaction.unit} from ${item.name}. Value: ETB ${valueLost.toFixed(2)}`, 'warning');

        this.clearReduceForm();
        this.initReducePage();
        this.renderTable();
        this.updateReviewDashboard();
        this.renderDeductionHistory();
        this.checkNotifications();
    }

    clearReduceForm() {
        (document.getElementById('reduceItemSelect') as HTMLSelectElement).value = '';
        (document.getElementById('reduceAvailable') as HTMLInputElement).value = '';
        (document.getElementById('reduceQtyDisplay') as HTMLInputElement).value = '1';
        (document.getElementById('reduceValueLostDisplay') as HTMLDivElement).innerHTML = 'ETB 0.00';
        (document.getElementById('reduceReason') as HTMLSelectElement).value = 'sale';
        (document.getElementById('whom') as HTMLInputElement).value = '';
        (document.getElementById('reduceNotes') as HTMLTextAreaElement).value = '';
    }

    renderDeductionHistory() {
        const tbody = document.getElementById('deductionHistoryBody');
        const footer = document.getElementById('deductionFooter');
        if (!tbody) return;

        const filtered = this.transactions.filter(t => t.branch === this.currentBranch);
        let totalLost = 0;

        tbody.innerHTML = filtered.slice(0, 100).map(t => {
            totalLost += t.valueLost || 0;
            return `<tr>
                <td>${t.date}</td>
                <td>${this.escapeHtml(t.itemName)}</td>
                <td>${t.category || '-'}</td>
                <td>${t.type || '-'}</td>
                <td>${t.quantity.toFixed(2)}</td>
                <td>${t.unit}</td>
                <td>${t.batch}</td>
                <td>${t.expiry}</td>
                <td><span class="status-indicator ${t.reason === 'expired' || t.reason === 'damaged' ? 'status-expired' : 'status-ok'}"></span>${t.reason}</td>
                <td>${t.branch}</td>
                <td>${t.warehouse || '-'}</td>
                <td>${t.storageCondition || '-'}</td>
                <td>${t.shelfBin || '-'}</td>
                <td>${t.responsible}</td>
                <td class="variance-negative">ETB ${(t.valueLost || 0).toFixed(2)}</td>
            </tr>`;
        }).join('') || '<tr><td colspan="15" style="text-align:center;">No deduction records</td></tr>';

        if (footer) {
            footer.innerHTML = `<tr class="total-row"><td colspan="14" style="text-align: right;">TOTAL LOSS VALUE:</td><td class="variance-negative">ETB ${totalLost.toFixed(2)}</td></tr>`;
        }
    }

    // ============================================================
    // REQUIREMENT 3 & 4: INVENTORY PAGE RENDERING & CALCULATIONS
    // ============================================================
    renderTable() {
        const tbody = document.getElementById('stockTableBody');
        const footer = document.getElementById('inventoryFooter');
        if (!tbody) return;

        let items = this.stockItems.filter(i => i.branch === this.currentBranch);
        const search = (document.getElementById('searchInput') as HTMLInputElement)?.value.toLowerCase() || '';
        if (search) items = items.filter(i => i.name.toLowerCase().includes(search) || i.batchNumber?.toLowerCase().includes(search) || i.brandName?.toLowerCase().includes(search));

        const category = (document.getElementById('categoryFilter') as HTMLSelectElement)?.value;
        if (category) items = items.filter(i => i.category === category);

        const branch = (document.getElementById('branchFilter') as HTMLSelectElement)?.value;
        if (branch) items = items.filter(i => i.branch === branch);

        const status = (document.getElementById('statusFilter') as HTMLSelectElement)?.value;
        if (status) {
            const now = new Date();
            items = items.filter(i => {
                const expiry = new Date(i.expiryDate);
                const diff = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
                const displayQty = i.quantityDisplay;
                switch (status) {
                    case 'low': return displayQty > 0 && displayQty < i.minStockDisplay;
                    case 'over': return displayQty > i.maxStockDisplay;
                    case 'expiry': return diff > 0 && diff <= 90;
                    case 'expired': return diff < 0;
                    case 'stockout': return displayQty <= 0;
                    case 'reorder': return displayQty <= i.reorderLevelDisplay;
                    case 'fast': return i.movement === 'fast';
                    case 'slow': return i.movement === 'slow';
                    default: return true;
                }
            });
        }

        // Sorting
        const sortMode = this.currentSort.inventory;
        if (sortMode === 'name-asc') {
            items.sort((a, b) => a.name.localeCompare(b.name));
        } else if (sortMode === 'name-desc') {
            items.sort((a, b) => b.name.localeCompare(a.name));
        } else {
            items.sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());
        }

        this.updateCategoryFilter();

        if (items.length === 0) {
            tbody.innerHTML = '<tr><td colspan="24" style="text-align:center;">No stock items found</td></tr>';
            if (footer) footer.innerHTML = '';
            return;
        }

        let totalValueAll = 0, totalQtyAll = 0, totalCostAll = 0;

        tbody.innerHTML = items.map(item => {
            const total = item.quantityDisplay * item.sellingPricePerDisplay;
            const cost = item.quantityDisplay * item.purchasePricePerDisplay;
            totalValueAll += total;
            totalQtyAll += item.quantityDisplay;
            totalCostAll += cost;

            const margin = cost > 0 ? ((total - cost) / cost * 100) : 0;
            const expiry = new Date(item.expiryDate);
            const diff = Math.ceil((expiry.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
            const expiryClass = diff < 0 ? 'status-expired' : diff <= 30 ? 'status-critical' : diff <= 90 ? 'status-warning' : 'status-ok';

            const begBal = item.beginningBalance !== undefined ? item.beginningBalance : item.quantityDisplay;
            const received = item.quantityReceived !== undefined ? item.quantityReceived : item.quantityDisplay;
            const issued = item.quantityIssued || 0;
            const expectedEnding = begBal + received - issued;
            const physicalCount = item.physicalCount !== undefined ? item.physicalCount : item.quantityDisplay;
            const variance = physicalCount - expectedEnding;

            const varianceClass = variance >= 0 ? 'variance-positive' : 'variance-negative';
            const varianceSymbol = variance >= 0 ? '+' : '';

            return `<tr data-id="${item.id}">
                <td><strong>${this.escapeHtml(item.name)}</strong>${item.brandName ? `<br><small style="color:var(--gray)">${this.escapeHtml(item.brandName)}</small>` : ''}</td>
                <td>${item.category}</td>
                <td>${item.type || '-'}</td>
                <td>${item.baseUnit}</td>
                <td>${item.registeredUnit}</td>
                <td>${item.displayUnit}</td>
                <td>${item.quantityBase.toFixed(2)}</td>
                <td>${(item.quantityRegistered || 0).toFixed(2)}</td>
                <td><strong style="color:var(--accent);">${item.quantityDisplay.toFixed(2)}</strong></td>
                <td>${begBal.toFixed(2)}</td>
                <td>${received.toFixed(2)}</td>
                <td>${issued.toFixed(2)}</td>
                <td>${expectedEnding.toFixed(2)}</td>
                <td><input type="number" class="physical-count-input" data-id="${item.id}" value="${physicalCount.toFixed(2)}" style="width:80px; padding:4px;"></td>
                <td class="${varianceClass}">${varianceSymbol}${variance.toFixed(2)}</td>
                <td>${item.minStockDisplay}/${item.reorderLevelDisplay}/${item.maxStockDisplay}</td>
                <td>ETB ${item.purchasePricePerDisplay.toFixed(2)}</td>
                <td>ETB ${item.sellingPricePerDisplay.toFixed(2)}</td>
                <td style="color:${margin >= 0 ? 'var(--success)' : 'var(--danger)'};">${margin.toFixed(1)}%</td>
                <td><strong>ETB ${total.toFixed(2)}</strong></td>
                <td>${item.batchNumber}</td>
                <td><span class="status-indicator ${expiryClass}"></span>${expiry.toLocaleDateString()}</td>
                <td>${diff > 0 ? `${diff} days` : 'EXPIRED'}</td>
                <td>
                    <div class="action-buttons">
                        <button class="action-btn edit-item" title="Edit Item"><i class="fas fa-edit"></i></button>
                        <button class="action-btn reduce-item" title="Deduct Stock"><i class="fas fa-minus"></i></button>
                        <button class="action-btn verify-item" title="Verify Count"><i class="fas fa-check-double"></i></button>
                    </div>
                </td>
            </tr>`;
        }).join('');

        if (footer) {
            footer.innerHTML = `<tr class="total-row">
                <td colspan="8" style="text-align: right;">TOTAL:</td>
                <td>${totalQtyAll.toFixed(2)}</td>
                <td colspan="9" style="text-align:right;">Total Inventory Selling Value:</td>
                <td colspan="6">ETB ${totalValueAll.toFixed(2)} (Cost: ETB ${totalCostAll.toFixed(2)})</td>
            </tr>`;
        }

        this.attachInventoryRowEvents();
    }

    attachInventoryRowEvents() {
        document.querySelectorAll('.edit-item').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt((e.target as HTMLElement).closest('tr')!.dataset.id!);
                this.editItem(id);
            });
        });

        document.querySelectorAll('.reduce-item').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt((e.target as HTMLElement).closest('tr')!.dataset.id!);
                this.openPage('reduceStockPage');
                setTimeout(() => {
                    const sel = document.getElementById('reduceItemSelect') as HTMLSelectElement;
                    if (sel) {
                        sel.value = id.toString();
                        sel.dispatchEvent(new Event('change'));
                    }
                }, 50);
            });
        });

        document.querySelectorAll('.verify-item').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt((e.target as HTMLElement).closest('tr')!.dataset.id!);
                this.verifyStock(id);
            });
        });

        document.querySelectorAll('.physical-count-input').forEach(inp => {
            inp.addEventListener('change', (e) => {
                const target = e.target as HTMLInputElement;
                const id = parseInt(target.dataset.id!);
                const newCount = parseFloat(target.value);
                this.updatePhysicalCount(id, newCount);
            });
        });
    }

    updatePhysicalCount(id: number, newCount: number) {
        const item = this.stockItems.find(i => i.id === id);
        if (item && !isNaN(newCount)) {
            const expectedEnding = (item.beginningBalance || item.quantityDisplay) + (item.quantityReceived || item.quantityDisplay) - (item.quantityIssued || 0);
            item.physicalCount = newCount;
            item.variance = newCount - expectedEnding;

            this.recordAudit('verification', item.id, item.name, Math.abs(item.variance), 'stock_verify', this.currentBranch, this.currentUserType || 'User', {
                expected: expectedEnding,
                physical: newCount,
                variance: item.variance
            });

            this.saveToLocalStorage();
            this.renderTable();
            this.showToast(`${item.name}: Physical count updated. Variance: ${item.variance >= 0 ? '+' : ''}${item.variance.toFixed(2)} ${item.displayUnit}`, item.variance === 0 ? 'success' : 'warning');
        }
    }

    verifyStock(id: number) {
        if (this.currentUserType !== 'admin') {
            this.showToast('Admin access required for stock verification', 'warning');
            return;
        }
        const item = this.stockItems.find(i => i.id === id);
        if (!item) return;

        const expectedEnding = (item.beginningBalance || item.quantityDisplay) + (item.quantityReceived || item.quantityDisplay) - (item.quantityIssued || 0);
        const physical = prompt(`Verify ${item.name}\nExpected Ending Balance: ${expectedEnding.toFixed(2)} ${item.displayUnit}\nCurrent Physical Count: ${item.physicalCount !== undefined ? item.physicalCount : item.quantityDisplay} ${item.displayUnit}\n\nEnter new physical count:`, (item.physicalCount || item.quantityDisplay).toString());
        if (physical !== null) {
            this.updatePhysicalCount(id, parseFloat(physical));
        }
    }

    verifyAllBalances() {
        if (this.currentUserType !== 'admin') {
            this.showToast('Admin access required to verify all balances', 'warning');
            return;
        }
        let accurate = 0;
        let discrepancies = 0;
        this.stockItems.forEach(item => {
            const expected = (item.beginningBalance || item.quantityDisplay) + (item.quantityReceived || item.quantityDisplay) - (item.quantityIssued || 0);
            const physical = item.physicalCount !== undefined ? item.physicalCount : item.quantityDisplay;
            if (Math.abs(physical - expected) <= 0.01) accurate++;
            else discrepancies++;
        });

        this.showToast(`Verification completed: ${accurate} accurate, ${discrepancies} variances flagged`, discrepancies > 0 ? 'warning' : 'success');
        this.renderTable();
    }

    editItem(id: number) {
        const item = this.stockItems.find(i => i.id === id);
        if (!item) return;
        this.openPage('registerStockPage');

        setTimeout(() => {
            (document.getElementById('itemIdInput') as HTMLInputElement).value = item.customId || '';
            (document.getElementById('itemName') as HTMLInputElement).value = item.name;
            (document.getElementById('brandName') as HTMLInputElement).value = item.brandName || '';
            (document.getElementById('category') as HTMLInputElement).value = item.category || '';
            (document.getElementById('itemType') as HTMLInputElement).value = item.type || '';
            (document.getElementById('baseUnit') as HTMLInputElement).value = item.baseUnit;
            (document.getElementById('registeredUnit') as HTMLInputElement).value = item.registeredUnit;
            (document.getElementById('displayUnit') as HTMLInputElement).value = item.displayUnit;
            (document.getElementById('registeredToBaseFactor') as HTMLInputElement).value = item.registeredToBaseFactor;
            (document.getElementById('displayToBaseFactor') as HTMLInputElement).value = item.displayToBaseFactor;
            (document.getElementById('qtyDisplay') as HTMLInputElement).value = item.quantityDisplay;
            (document.getElementById('purchasePricePerDisplay') as HTMLInputElement).value = item.purchasePricePerDisplay;
            (document.getElementById('markup') as HTMLInputElement).value = item.markup;
            (document.getElementById('discountPercent') as HTMLInputElement).value = item.discountPercent || 0;
            (document.getElementById('sellingPricePerDisplay') as HTMLInputElement).value = item.sellingPricePerDisplay;
            (document.getElementById('batchNumber') as HTMLInputElement).value = item.batchNumber;
            (document.getElementById('expiryDate') as HTMLInputElement).value = item.expiryDate;
            (document.getElementById('supplier') as HTMLInputElement).value = item.supplier || '';
            (document.getElementById('invoiceNumber') as HTMLInputElement).value = item.invoiceNumber || '';
            (document.getElementById('registrant') as HTMLInputElement).value = item.registrant || '';
            (document.getElementById('branch') as HTMLSelectElement).value = item.branch || 'pharmacy';
            (document.getElementById('warehouse') as HTMLSelectElement).value = item.warehouse || 'main';
            (document.getElementById('storageCondition') as HTMLSelectElement).value = item.storageCondition || 'ambient';
            (document.getElementById('shelfBin') as HTMLInputElement).value = item.shelfBin || '';
            (document.getElementById('minStockDisplay') as HTMLInputElement).value = item.minStockDisplay;
            (document.getElementById('maxStockDisplay') as HTMLInputElement).value = item.maxStockDisplay;
            (document.getElementById('reorderLevelDisplay') as HTMLInputElement).value = item.reorderLevelDisplay;

            this.isEditing = true;
            this.editingId = id;
            document.getElementById('saveBtn')!.innerHTML = '<i class="fas fa-sync-alt"></i> Update Item';

            // Trigger conversion preview
            document.getElementById('qtyDisplay')?.dispatchEvent(new Event('input'));
        }, 50);
    }

    saveItem() {
        const name = (document.getElementById('itemName') as HTMLInputElement).value.trim();
        if (!name) {
            this.showToast('Please enter item generic name', 'warning');
            return;
        }

        const baseUnit = (document.getElementById('baseUnit') as HTMLInputElement).value.trim() || 'piece';
        const registeredUnit = (document.getElementById('registeredUnit') as HTMLInputElement).value.trim() || 'box';
        const displayUnit = (document.getElementById('displayUnit') as HTMLInputElement).value.trim() || 'piece';
        const regFactor = Math.max(0.0001, parseFloat((document.getElementById('registeredToBaseFactor') as HTMLInputElement).value) || 1);
        const dispFactor = Math.max(0.0001, parseFloat((document.getElementById('displayToBaseFactor') as HTMLInputElement).value) || 1);

        const entryUnit = (document.getElementById('unitSelector') as HTMLSelectElement).value || 'displayUnit';
        const enteredQty = parseFloat((document.getElementById('qtyDisplay') as HTMLInputElement).value) || 0;

        let baseQty = 0;
        if (entryUnit === 'baseUnit') baseQty = enteredQty;
        else if (entryUnit === 'registeredUnit') baseQty = enteredQty * regFactor;
        else baseQty = enteredQty * dispFactor;

        const dispQty = baseQty / dispFactor;
        const regQty = baseQty / regFactor;

        const purchasePrice = parseFloat((document.getElementById('purchasePricePerDisplay') as HTMLInputElement).value) || 0;
        const markup = parseFloat((document.getElementById('markup') as HTMLInputElement).value) || 0;
        const discount = parseFloat((document.getElementById('discountPercent') as HTMLInputElement).value) || 0;
        let sellingPrice = parseFloat((document.getElementById('sellingPricePerDisplay') as HTMLInputElement).value) || 0;
        if (sellingPrice <= 0) sellingPrice = purchasePrice * (1 + markup / 100);

        const itemData: any = {
            id: this.isEditing ? this.editingId : this.currentId++,
            customId: (document.getElementById('itemIdInput') as HTMLInputElement).value.trim() || `ITEM-${Date.now()}`,
            name: name,
            brandName: (document.getElementById('brandName') as HTMLInputElement).value.trim(),
            category: (document.getElementById('category') as HTMLInputElement).value.trim() || 'General',
            type: (document.getElementById('itemType') as HTMLInputElement).value.trim() || 'Medicine',
            baseUnit: baseUnit,
            registeredUnit: registeredUnit,
            displayUnit: displayUnit,
            registeredToBaseFactor: regFactor,
            displayToBaseFactor: dispFactor,
            allowFractionalDisplay: (document.getElementById('allowFractionalDisplay') as HTMLSelectElement).value === 'true',
            quantityBase: baseQty,
            quantityRegistered: regQty,
            quantityDisplay: dispQty,
            purchasePricePerDisplay: purchasePrice,
            markup: markup,
            discountPercent: discount,
            sellingPricePerDisplay: sellingPrice,
            batchNumber: (document.getElementById('batchNumber') as HTMLInputElement).value.trim() || `BATCH-${Date.now()}`,
            expiryDate: (document.getElementById('expiryDate') as HTMLInputElement).value,
            supplier: (document.getElementById('supplier') as HTMLInputElement).value.trim() || 'Supplier',
            invoiceNumber: (document.getElementById('invoiceNumber') as HTMLInputElement).value.trim() || '',
            registrant: (document.getElementById('registrant') as HTMLInputElement).value.trim() || (this.currentUserType || 'User'),
            branch: (document.getElementById('branch') as HTMLSelectElement).value || 'pharmacy',
            warehouse: (document.getElementById('warehouse') as HTMLSelectElement).value || 'main',
            storageCondition: (document.getElementById('storageCondition') as HTMLSelectElement).value || 'ambient',
            shelfBin: (document.getElementById('shelfBin') as HTMLInputElement).value.trim(),
            minStockDisplay: parseFloat((document.getElementById('minStockDisplay') as HTMLInputElement).value) || 10,
            maxStockDisplay: parseFloat((document.getElementById('maxStockDisplay') as HTMLInputElement).value) || 100,
            reorderLevelDisplay: parseFloat((document.getElementById('reorderLevelDisplay') as HTMLInputElement).value) || 20,
            minStockBase: (parseFloat((document.getElementById('minStockDisplay') as HTMLInputElement).value) || 10) * dispFactor,
            maxStockBase: (parseFloat((document.getElementById('maxStockDisplay') as HTMLInputElement).value) || 100) * dispFactor,
            reorderLevelBase: (parseFloat((document.getElementById('reorderLevelDisplay') as HTMLInputElement).value) || 20) * dispFactor,
            beginningBalance: dispQty,
            quantityReceived: dispQty,
            quantityIssued: 0,
            endingBalance: dispQty,
            physicalCount: dispQty,
            variance: 0,
            movement: 'normal',
            createdAt: new Date().toISOString(),
            movementHistory: []
        };

        if (this.isEditing) {
            const idx = this.stockItems.findIndex(i => i.id === itemData.id);
            if (idx >= 0) this.stockItems[idx] = itemData;
            this.showToast(`Item "${name}" updated successfully`, 'success');
            this.recordAudit('edit', itemData.id, itemData.name, dispQty, 'item_edit', itemData.branch, this.currentUserType || 'User');
        } else {
            this.stockItems.push(itemData);
            this.showToast(`Item "${name}" registered successfully`, 'success');
            this.recordAudit('purchase', itemData.id, itemData.name, dispQty, 'stock_in', itemData.branch, itemData.registrant, {
                value: dispQty * purchasePrice
            });
        }

        this.saveToLocalStorage();
        this.clearRegisterForm();
        this.updateItemNameList();
        this.updateDatalists();
        this.renderTable();
        this.renderRecentRegistrations();
        this.updateReviewDashboard();
        this.checkNotifications();

        this.isEditing = false;
        this.editingId = null;
        document.getElementById('saveBtn')!.innerHTML = '<i class="fas fa-save"></i> Save Item';
    }

    clearRegisterForm() {
        (document.getElementById('stockForm') as HTMLFormElement).reset();
        (document.getElementById('expiryDate') as HTMLInputElement).value = new Date().toISOString().split('T')[0];
        (document.getElementById('markup') as HTMLInputElement).value = this.settings.defaultMarkup.toString();
        (document.getElementById('discountPercent') as HTMLInputElement).value = '0';
        (document.getElementById('branch') as HTMLSelectElement).value = this.currentBranch;
        (document.getElementById('itemIdInput') as HTMLInputElement).value = '';
        (document.getElementById('brandName') as HTMLInputElement).value = '';
        (document.getElementById('qtyDisplay') as HTMLInputElement).value = '10';
        (document.getElementById('registeredToBaseFactor') as HTMLInputElement).value = '100';
        (document.getElementById('displayToBaseFactor') as HTMLInputElement).value = '10';
        (document.getElementById('purchasePricePerDisplay') as HTMLInputElement).value = '50';
        (document.getElementById('sellingPricePerDisplay') as HTMLInputElement).value = '75';
        document.getElementById('qtyDisplay')?.dispatchEvent(new Event('input'));
    }

    renderRecentRegistrations() {
        const tbody = document.getElementById('recentRegistrationsBody');
        if (!tbody) return;
        const recent = [...this.stockItems]
            .filter(i => i.branch === this.currentBranch)
            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
            .slice(0, 20);

        tbody.innerHTML = recent.map(i => `
            <tr>
                <td>${new Date(i.createdAt).toLocaleDateString()}</td>
                <td><strong>${this.escapeHtml(i.name)}</strong></td>
                <td>${i.baseUnit}</td>
                <td>${i.registeredUnit}</td>
                <td>${i.displayUnit}</td>
                <td>${i.quantityBase.toFixed(2)}</td>
                <td>${(i.quantityRegistered || 0).toFixed(2)}</td>
                <td>${i.quantityDisplay.toFixed(2)}</td>
                <td>${i.batchNumber}</td>
                <td>${i.expiryDate}</td>
            </tr>
        `).join('') || '<tr><td colspan="10" style="text-align:center;">No recent registrations</td></tr>';
    }

    // ============================================================
    // REQUIREMENT 4 & 5: NAVIGATION, NOTIFICATIONS & REVIEW
    // ============================================================
    openPage(pageId: string, filter: string | null = null) {
        if (!this.isLoggedIn) {
            this.showToast('Please login to access this section', 'warning');
            return;
        }

        // Role-based security check
        if ((pageId === 'reviewPage' || pageId === 'auditPage') && this.currentUserType !== 'admin') {
            this.showToast('Access restricted: Administrator role required', 'warning');
            return;
        }

        document.querySelectorAll('.full-screen-mode').forEach(p => p.classList.remove('active'));
        const targetPage = document.getElementById(pageId);
        if (targetPage) {
            targetPage.classList.add('active');
            targetPage.scrollTop = 0;
        }

        const branchLabel = document.getElementById(`${pageId.replace('Page', '')}BranchLabel`) || document.getElementById(`${pageId}BranchLabel`);
        if (branchLabel) branchLabel.textContent = this.currentBranch === 'pharmacy' ? 'Pharmacy' : 'Wholesaler';

        switch (pageId) {
            case 'registerStockPage':
                this.renderRecentRegistrations();
                break;
            case 'salesPage':
                (document.getElementById('salesDate') as HTMLInputElement).value = new Date().toISOString().split('T')[0];
                if (!(document.getElementById('salesInvoiceNumber') as HTMLInputElement).value) {
                    (document.getElementById('salesInvoiceNumber') as HTMLInputElement).value = `INV-${Date.now()}`;
                }
                this.renderSalesHistory();
                break;
            case 'stockInventoryPage':
                this.renderTable();
                if (filter) {
                    setTimeout(() => {
                        const statusFilter = document.getElementById('statusFilter') as HTMLSelectElement;
                        if (statusFilter) {
                            statusFilter.value = filter;
                            this.renderTable();
                        }
                    }, 50);
                }
                break;
            case 'reduceStockPage':
                this.initReducePage();
                break;
            case 'reviewPage':
                this.updateReviewDashboard();
                this.renderActivityLog();
                this.renderDemandForecastDetail();
                this.renderReorderDetail();
                this.renderLossReasonsTable();
                this.renderCostSellingComparison();
                this.renderVarianceTracking();
                break;
            case 'auditPage':
                this.renderAuditTable();
                this.updateAuditSummary();
                this.renderAuditVarianceDetail();
                this.updateAuditWithNetProfit();
                break;
        }
    }

    setupEndingBalanceButton() {
        const btn = document.getElementById('endingBalanceBtn');
        const panel = document.getElementById('endingBalancePanel');
        const content = document.getElementById('endingBalanceContent');
        if (!btn || !panel || !content) return;

        btn.addEventListener('click', () => {
            const items = this.stockItems.filter(i => i.branch === this.currentBranch);
            if (items.length === 0) {
                content.innerHTML = '<p>No inventory records found for the current branch.</p>';
                panel.style.display = 'block';
                return;
            }

            let totalEndingDisp = 0;
            let totalEndingValue = 0;
            let totalBeginning = 0;
            let totalReceived = 0;
            let totalIssued = 0;

            const rowsHtml = items.map(item => {
                const beg = item.beginningBalance !== undefined ? item.beginningBalance : item.quantityDisplay;
                const rec = item.quantityReceived !== undefined ? item.quantityReceived : item.quantityDisplay;
                const iss = item.quantityIssued || 0;
                const ending = beg + rec - iss;
                const value = ending * item.sellingPricePerDisplay;

                totalBeginning += beg;
                totalReceived += rec;
                totalIssued += iss;
                totalEndingDisp += ending;
                totalEndingValue += value;

                return `
                    <tr style="border-bottom:1px solid rgba(255,215,0,0.1);">
                        <td style="padding:6px;"><strong>${this.escapeHtml(item.name)}</strong></td>
                        <td style="padding:6px;">${item.baseUnit}</td>
                        <td style="padding:6px;">${item.displayUnit}</td>
                        <td style="padding:6px;">${beg.toFixed(2)}</td>
                        <td style="padding:6px;">${rec.toFixed(2)}</td>
                        <td style="padding:6px;">${iss.toFixed(2)}</td>
                        <td style="padding:6px; font-weight:bold; color:var(--success);">${ending.toFixed(2)}</td>
                        <td style="padding:6px; font-weight:bold; color:var(--accent);">ETB ${value.toFixed(2)}</td>
                    </tr>
                `;
            }).join('');

            content.innerHTML = `
                <div style="overflow-x:auto;">
                    <table style="width:100%; font-size:0.8rem; border-collapse:collapse; margin-top:0.5rem;">
                        <thead>
                            <tr style="background:rgba(255,215,0,0.15); color:var(--accent);">
                                <th style="padding:6px; text-align:left;">Item Name</th>
                                <th style="padding:6px; text-align:left;">Base Unit</th>
                                <th style="padding:6px; text-align:left;">Display Unit</th>
                                <th style="padding:6px; text-align:left;">Beginning</th>
                                <th style="padding:6px; text-align:left;">Received</th>
                                <th style="padding:6px; text-align:left;">Issued/Sold</th>
                                <th style="padding:6px; text-align:left;">Ending Balance</th>
                                <th style="padding:6px; text-align:left;">Ending Valuation</th>
                            </tr>
                        </thead>
                        <tbody>${rowsHtml}</tbody>
                        <tfoot>
                            <tr style="background:rgba(0,255,136,0.1); font-weight:bold; border-top:2px solid var(--accent);">
                                <td colspan="3" style="padding:6px; text-align:right;">TOTALS:</td>
                                <td style="padding:6px;">${totalBeginning.toFixed(2)}</td>
                                <td style="padding:6px;">${totalReceived.toFixed(2)}</td>
                                <td style="padding:6px;">${totalIssued.toFixed(2)}</td>
                                <td style="padding:6px; color:var(--success);">${totalEndingDisp.toFixed(2)}</td>
                                <td style="padding:6px; color:var(--accent);">ETB ${totalEndingValue.toFixed(2)}</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <p style="margin-top:0.8rem; color:var(--gray); font-size:0.8rem;">Ending Balance = Beginning + Received − Issued/Sold. Valuations calculated via current selling price.</p>
            `;

            panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
            if (panel.style.display === 'block') {
                panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                this.showToast('Ending balance summary refreshed', 'info');
            }
        });
    }

    // ============================================================
    // REQUIREMENT 5: NOTIFICATION BAR & ALERTS
    // ============================================================
    startNotificationSystem() {
        this.checkNotifications();
        this.notificationInterval = setInterval(() => this.checkNotifications(), 45000);
    }

    checkNotifications() {
        const notifs: any[] = [];
        const now = new Date();

        this.stockItems.forEach(item => {
            const expiryDate = new Date(item.expiryDate);
            const diffDays = Math.ceil((expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
            const dispQty = item.quantityDisplay;

            if (diffDays < 0 && this.settings.notifyExpiry) {
                notifs.push({
                    id: `exp-${item.id}`, type: 'critical', title: '🚨 Item Expired',
                    message: `${item.name} (${item.batchNumber}) has expired! Immediate deduction required.`,
                    itemId: item.id, page: 'stockInventoryPage', filter: 'expired', reviewed: false
                });
            } else if (diffDays <= this.settings.expiryWarningDays && diffDays > 0 && this.settings.notifyExpiry) {
                notifs.push({
                    id: `exp30-${item.id}`, type: 'critical', title: '⏰ Urgent: Expiry Within 30 Days',
                    message: `${item.name} expires in ${diffDays} days (${item.batchNumber})`,
                    itemId: item.id, page: 'stockInventoryPage', filter: 'expiry', reviewed: false
                });
            } else if (diffDays <= this.settings.expiryWarningDays60 && diffDays > 0 && this.settings.notifyExpiry) {
                notifs.push({
                    id: `exp60-${item.id}`, type: 'warning', title: '⚠️ Near Expiry Warning',
                    message: `${item.name} expires in ${diffDays} days`,
                    itemId: item.id, page: 'stockInventoryPage', filter: 'expiry', reviewed: false
                });
            }

            if (dispQty <= 0 && this.settings.notifyReorder) {
                notifs.push({
                    id: `stkout-${item.id}`, type: 'critical', title: '🛑 Stock Out Alert',
                    message: `${item.name} is completely out of stock!`,
                    itemId: item.id, page: 'stockInventoryPage', filter: 'stockout', reviewed: false
                });
            } else if (dispQty <= item.reorderLevelDisplay && dispQty > 0 && this.settings.notifyReorder) {
                notifs.push({
                    id: `reord-${item.id}`, type: 'critical', title: '📦 Reorder Level Reached',
                    message: `${item.name} is at reorder level (${dispQty.toFixed(2)} ${item.displayUnit} remaining)`,
                    itemId: item.id, page: 'stockInventoryPage', filter: 'reorder', reviewed: false
                });
            } else if (dispQty < item.minStockDisplay && dispQty > 0 && this.settings.notifyLowStock) {
                notifs.push({
                    id: `low-${item.id}`, type: 'warning', title: '📉 Low Stock Warning',
                    message: `${item.name} is below minimum stock (${dispQty.toFixed(2)} ${item.displayUnit})`,
                    itemId: item.id, page: 'stockInventoryPage', filter: 'low', reviewed: false
                });
            } else if (dispQty > item.maxStockDisplay && this.settings.notifyOverstock) {
                notifs.push({
                    id: `over-${item.id}`, type: 'info', title: 'ℹ️ Overstock Update',
                    message: `${item.name} exceeds max capacity (${dispQty.toFixed(2)} ${item.displayUnit})`,
                    itemId: item.id, page: 'stockInventoryPage', filter: 'over', reviewed: false
                });
            }
        });

        this.notifications = notifs;
        this.updateNotificationCounters();
    }

    updateNotificationCounters() {
        const critical = this.notifications.filter(n => n.type === 'critical' && !n.reviewed).length;
        const warning = this.notifications.filter(n => n.type === 'warning' && !n.reviewed).length;
        const info = this.notifications.filter(n => n.type === 'info' && !n.reviewed).length;

        const criticalSpan = document.getElementById('criticalCounter')?.querySelector('.count');
        const warningSpan = document.getElementById('warningCounter')?.querySelector('.count');
        const infoSpan = document.getElementById('infoCounter')?.querySelector('.count');

        if (criticalSpan) criticalSpan.textContent = critical.toString();
        if (warningSpan) warningSpan.textContent = warning.toString();
        if (infoSpan) infoSpan.textContent = info.toString();
    }

    openNotificationPanel(type: 'critical' | 'warning' | 'info') {
        const panel = document.getElementById('notificationPanel');
        const list = document.getElementById('notificationList');
        const title = document.getElementById('notificationPanelTitle');
        if (!panel || !list) return;

        const filtered = this.notifications.filter(n => n.type === type && !n.reviewed);
        if (title) {
            title.innerHTML = type === 'critical' 
                ? '<i class="fas fa-exclamation-circle" style="color:var(--danger)"></i> Urgent Alerts' 
                : type === 'warning' 
                ? '<i class="fas fa-exclamation-triangle" style="color:var(--warning)"></i> Warnings' 
                : '<i class="fas fa-info-circle" style="color:var(--accent)"></i> System Updates';
        }

        list.innerHTML = filtered.map(n => `
            <div class="notification-list-item ${n.type}" data-notif-id="${n.id}">
                <div style="font-weight:bold; color:var(--light); font-size:0.95rem;">${n.title}</div>
                <div style="margin:4px 0; color:var(--light); opacity:0.9;">${n.message}</div>
                <div style="font-size:0.75rem; color:var(--gray);">${new Date().toLocaleTimeString()}</div>
                <div class="actions">
                    <button class="notification-action-btn" onclick="window.ultraStock.reviewNotification('${n.id}')">
                        <i class="fas fa-check"></i> Review & Clear
                    </button>
                    <button class="notification-action-btn" onclick="window.ultraStock.goToNotification('${n.id}')" style="border-color:var(--accent); color:var(--accent); background:rgba(255,215,0,0.1);">
                        <i class="fas fa-arrow-right"></i> Go to Item
                    </button>
                </div>
            </div>
        `).join('') || '<div style="text-align:center; padding:1.5rem; color:var(--gray);">No active notifications in this category</div>';

        panel.classList.add('active');
    }

    closeNotificationPanel() {
        document.getElementById('notificationPanel')?.classList.remove('active');
    }

    reviewNotification(notifId: string) {
        const notif = this.notifications.find(n => n.id === notifId);
        if (notif) {
            notif.reviewed = true;
            this.updateNotificationCounters();
            const el = document.querySelector(`.notification-list-item[data-notif-id="${notifId}"]`);
            if (el) el.remove();
            this.showToast(`Notification reviewed & cleared`, 'success');
        }
    }

    goToNotification(notifId: string) {
        const notif = this.notifications.find(n => n.id === notifId);
        if (!notif) return;
        this.closeNotificationPanel();
        this.openPage(notif.page, notif.filter);
        this.showToast(`Navigated to: ${notif.title}`, 'info');
    }

    showToast(message: string, type: string = 'info') {
        const container = document.getElementById('toastContainer');
        if (!container) return;

        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        const icon = type === 'critical' || type === 'danger' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : type === 'success' ? 'check-circle' : 'info-circle';
        
        toast.innerHTML = `
            <i class="fas fa-${icon}"></i>
            <span style="flex:1;">${message}</span>
            <button type="button" style="background:none; border:none; color:var(--light); cursor:pointer; font-size:1rem; opacity:0.8;" title="Dismiss">&times;</button>
        `;

        toast.querySelector('button')?.addEventListener('click', () => toast.remove());
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 5000);
    }

    // ============================================================
    // REQUIREMENT 6: 100% OFFLINE IMPORT & EXPORT
    // ============================================================
    setupExportImport() {
        const importBtn = document.getElementById('importExportBtn');
        const importDropdown = document.getElementById('importDropdown');
        if (importBtn && importDropdown) {
            importBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                importDropdown.classList.toggle('active');
            });
            document.addEventListener('click', () => importDropdown.classList.remove('active'));
        }

        document.getElementById('importExcelBtn')?.addEventListener('click', () => this.importExcel());
        document.getElementById('importWordBtn')?.addEventListener('click', () => this.importWord());

        const exportBtn = document.getElementById('exportDataBtn');
        const exportDropdownDiv = document.getElementById('exportDropdown');
        if (exportBtn && exportDropdownDiv) {
            exportBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                exportDropdownDiv.style.display = exportDropdownDiv.style.display === 'none' ? 'block' : 'none';
            });
            document.addEventListener('click', () => exportDropdownDiv.style.display = 'none');
        }

        document.getElementById('exportExcelBtn')?.addEventListener('click', () => this.exportData('excel'));
        document.getElementById('exportWordBtn')?.addEventListener('click', () => this.exportData('word'));

        document.querySelectorAll('.export-time-filter').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.export-time-filter').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                const period = (btn as HTMLElement).dataset.period || 'all';
                this.exportTimeFilter = period;
                const customDiv = document.getElementById('exportCustomDateRange');
                if (customDiv) customDiv.style.display = period === 'custom' ? 'block' : 'none';
            });
        });
    }

    async importExcel() {
        if (this.currentUserType !== 'admin') {
            this.showToast('Administrator access required for data import', 'warning');
            return;
        }

        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.xlsx, .xls';

        input.onchange = async (e: any) => {
            const file = e.target.files[0];
            if (!file) return;

            try {
                const arrayBuffer = await file.arrayBuffer();
                const workbook = XLSX.read(arrayBuffer, { type: 'array' });
                const firstSheetName = workbook.SheetNames[0];
                const sheet = workbook.Sheets[firstSheetName];
                const rows: any[] = XLSX.utils.sheet_to_json(sheet);

                if (!rows || rows.length === 0) {
                    this.showToast('The selected Excel file contains no records', 'warning');
                    return;
                }

                let imported = 0;
                let skipped = 0;

                rows.forEach((row, idx) => {
                    const name = row['Generic Name'] || row['Item Name'] || row['Name'];
                    if (!name) {
                        skipped++;
                        return;
                    }

                    const batchNumber = row['Batch Number'] || row['Batch'] || `IMP-${Date.now()}-${idx}`;
                    // Check duplicate by customId or (name + batchNumber)
                    const existing = this.stockItems.find(i => 
                        (row['Item ID'] && i.customId === row['Item ID']) ||
                        (i.name.toLowerCase() === name.toLowerCase() && i.batchNumber === batchNumber)
                    );

                    if (existing) {
                        skipped++;
                        return;
                    }

                    const regFactor = Math.max(0.0001, parseFloat(row['Register to Base Factor'] || row['RegToBaseFactor']) || 100);
                    const dispFactor = Math.max(0.0001, parseFloat(row['Display to Base Factor'] || row['DispToBaseFactor']) || 10);
                    const qtyDisplay = parseFloat(row['Quantity Display'] || row['Quantity'] || row['Qty']) || 0;
                    const baseQty = qtyDisplay * dispFactor;
                    const regQty = baseQty / regFactor;

                    const purchasePrice = parseFloat(row['Purchase Price'] || row['Cost']) || 0;
                    const markup = parseFloat(row['Markup %'] || row['Markup']) || this.settings.defaultMarkup;
                    let sellingPrice = parseFloat(row['Selling Price'] || row['Price']) || 0;
                    if (sellingPrice <= 0) sellingPrice = purchasePrice * (1 + markup / 100);

                    const newItem = {
                        id: this.currentId++,
                        customId: row['Item ID'] || `IMP-${Date.now()}-${idx}`,
                        name: name,
                        brandName: row['Brand Name'] || row['Brand'] || '',
                        category: row['Category'] || 'General',
                        type: row['Type'] || 'Medicine',
                        baseUnit: row['Base Unit'] || 'tablet',
                        registeredUnit: row['Register Unit'] || row['Registered Unit'] || 'box',
                        displayUnit: row['Display Unit'] || 'strip',
                        registeredToBaseFactor: regFactor,
                        displayToBaseFactor: dispFactor,
                        allowFractionalDisplay: row['Allow Fractional'] === 'true',
                        quantityBase: baseQty,
                        quantityRegistered: regQty,
                        quantityDisplay: qtyDisplay,
                        purchasePricePerDisplay: purchasePrice,
                        markup: markup,
                        discountPercent: parseFloat(row['Discount %']) || 0,
                        sellingPricePerDisplay: sellingPrice,
                        batchNumber: batchNumber,
                        expiryDate: row['Expiry Date'] || new Date(Date.now() + 365*86400000).toISOString().split('T')[0],
                        supplier: row['Supplier'] || 'Imported',
                        invoiceNumber: row['Invoice Number'] || '',
                        registrant: 'Admin (Excel Import)',
                        branch: row['Branch'] || this.currentBranch,
                        warehouse: row['Warehouse'] || 'main',
                        storageCondition: row['Storage Condition'] || 'ambient',
                        shelfBin: row['Shelf/Bin'] || '',
                        minStockDisplay: parseFloat(row['Min Stock']) || 10,
                        maxStockDisplay: parseFloat(row['Max Stock']) || 100,
                        reorderLevelDisplay: parseFloat(row['Reorder Level']) || 20,
                        minStockBase: (parseFloat(row['Min Stock']) || 10) * dispFactor,
                        maxStockBase: (parseFloat(row['Max Stock']) || 100) * dispFactor,
                        reorderLevelBase: (parseFloat(row['Reorder Level']) || 20) * dispFactor,
                        beginningBalance: qtyDisplay,
                        quantityReceived: qtyDisplay,
                        quantityIssued: 0,
                        endingBalance: qtyDisplay,
                        physicalCount: qtyDisplay,
                        variance: 0,
                        movement: 'normal',
                        createdAt: new Date().toISOString(),
                        movementHistory: []
                    };

                    this.stockItems.push(newItem);
                    imported++;
                });

                this.saveToLocalStorage();
                this.renderTable();
                this.updateItemNameList();
                this.updateDatalists();
                this.updateReviewDashboard();
                this.checkNotifications();
                this.showToast(`Import completed: ${imported} imported, ${skipped} skipped (duplicates/invalid)`, 'success');
            } catch (err: any) {
                console.error('Excel import error:', err);
                this.showToast('Error reading Excel file. Please ensure valid format.', 'danger');
            }
        };

        input.click();
    }

    async importWord() {
        if (this.currentUserType !== 'admin') {
            this.showToast('Administrator access required for data import', 'warning');
            return;
        }

        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.docx';

        input.onchange = async (e: any) => {
            const file = e.target.files[0];
            if (!file) return;

            try {
                const arrayBuffer = await file.arrayBuffer();
                const result = await mammoth.extractRawText({ arrayBuffer });
                const lines = result.value.split('\n').map(l => l.trim()).filter(Boolean);

                let imported = 0;
                lines.forEach((line, idx) => {
                    if (line.includes('|') || line.includes('\t')) {
                        const parts = line.split(/[|\t]/).map(p => p.trim());
                        if (parts.length >= 4 && !parts[0].toLowerCase().includes('item') && !parts[0].toLowerCase().includes('generic')) {
                            const name = parts[0];
                            const brand = parts[1] || '';
                            const category = parts[2] || 'General';
                            const qty = parseFloat(parts[3]) || 0;
                            const price = parseFloat(parts[4]) || 0;

                            const newItem = {
                                id: this.currentId++,
                                customId: `DOC-${Date.now()}-${idx}`,
                                name: name,
                                brandName: brand,
                                category: category,
                                type: 'Medicine',
                                baseUnit: 'tablet',
                                registeredUnit: 'box',
                                displayUnit: 'strip',
                                registeredToBaseFactor: 100,
                                displayToBaseFactor: 10,
                                allowFractionalDisplay: false,
                                quantityBase: qty * 10,
                                quantityRegistered: qty * 0.1,
                                quantityDisplay: qty,
                                purchasePricePerDisplay: price,
                                markup: 50,
                                discountPercent: 0,
                                sellingPricePerDisplay: price * 1.5,
                                batchNumber: `DOC-${Date.now()}`,
                                expiryDate: new Date(Date.now() + 365*86400000).toISOString().split('T')[0],
                                supplier: 'Word Import',
                                invoiceNumber: '',
                                registrant: 'Admin',
                                branch: this.currentBranch,
                                warehouse: 'main',
                                storageCondition: 'ambient',
                                shelfBin: '',
                                minStockDisplay: 10,
                                maxStockDisplay: 100,
                                reorderLevelDisplay: 20,
                                minStockBase: 100,
                                maxStockBase: 1000,
                                reorderLevelBase: 200,
                                beginningBalance: qty,
                                quantityReceived: qty,
                                quantityIssued: 0,
                                endingBalance: qty,
                                physicalCount: qty,
                                variance: 0,
                                movement: 'normal',
                                createdAt: new Date().toISOString(),
                                movementHistory: []
                            };

                            this.stockItems.push(newItem);
                            imported++;
                        }
                    }
                });

                if (imported > 0) {
                    this.saveToLocalStorage();
                    this.renderTable();
                    this.updateReviewDashboard();
                    this.showToast(`Imported ${imported} items from Word document`, 'success');
                } else {
                    this.showToast('No tabular or pipe-delimited data found in Word document', 'warning');
                }
            } catch (err) {
                console.error('Word import error:', err);
                this.showToast('Failed to parse Word document (.docx)', 'danger');
            }
        };

        input.click();
    }

    exportData(format: 'excel' | 'word') {
        const exportType = (document.getElementById('exportTypeSelect') as HTMLSelectElement)?.value || 'inventory';
        const itemFilter = (document.getElementById('exportItemFilter') as HTMLInputElement)?.value.trim().toLowerCase() || '';
        const categoryFilter = (document.getElementById('exportCategoryFilter') as HTMLInputElement)?.value.trim().toLowerCase() || '';

        let records: any[] = [];
        let filename = `ebp_${exportType}_${new Date().toISOString().slice(0, 10)}`;

        if (exportType === 'inventory') {
            records = this.stockItems.filter(i => i.branch === this.currentBranch);
            if (itemFilter) records = records.filter(i => i.name.toLowerCase().includes(itemFilter));
            if (categoryFilter) records = records.filter(i => (i.category || '').toLowerCase().includes(categoryFilter));
        } else if (exportType === 'sales') {
            records = this.salesData.filter(s => s.branch === this.currentBranch);
            if (itemFilter) records = records.filter(s => s.items?.some((i: any) => i.name.toLowerCase().includes(itemFilter)));
            if (categoryFilter) records = records.filter(s => s.items?.some((i: any) => (i.category || '').toLowerCase().includes(categoryFilter)));
        } else {
            records = this.transactions.filter(t => t.branch === this.currentBranch);
            if (itemFilter) records = records.filter(t => t.itemName.toLowerCase().includes(itemFilter));
            if (categoryFilter) records = records.filter(t => (t.category || '').toLowerCase().includes(categoryFilter));
        }

        if (records.length === 0) {
            this.showToast('No records match the export criteria', 'warning');
            return;
        }

        if (format === 'excel') {
            let sheetData: any[] = [];
            if (exportType === 'inventory') {
                sheetData = records.map(i => ({
                    'Item ID': i.customId,
                    'Generic Name': i.name,
                    'Brand Name': i.brandName || '',
                    'Category': i.category,
                    'Type': i.type,
                    'Base Unit': i.baseUnit,
                    'Register Unit': i.registeredUnit,
                    'Display Unit': i.displayUnit,
                    'Reg to Base Ratio': i.registeredToBaseFactor,
                    'Disp to Base Ratio': i.displayToBaseFactor,
                    'Qty (Base)': i.quantityBase.toFixed(2),
                    'Qty (Reg)': (i.quantityRegistered || 0).toFixed(2),
                    'Qty (Display)': i.quantityDisplay.toFixed(2),
                    'Purchase Price (Display)': i.purchasePricePerDisplay,
                    'Selling Price (Display)': i.sellingPricePerDisplay,
                    'Total Valuation': (i.quantityDisplay * i.sellingPricePerDisplay).toFixed(2),
                    'Batch Number': i.batchNumber,
                    'Expiry Date': i.expiryDate,
                    'Storage': i.storageCondition,
                    'Shelf/Bin': i.shelfBin
                }));
            } else if (exportType === 'sales') {
                records.forEach(s => {
                    s.items?.forEach((i: any) => {
                        sheetData.push({
                            'Date': s.date,
                            'Invoice': s.invoiceNumber,
                            'Item': i.name,
                            'Quantity': i.inputQuantity || i.displayQuantity,
                            'Unit': i.unitLabel,
                            'Unit Price': i.unitPrice,
                            'Total': i.netAmount,
                            'Discount': s.totalDiscount,
                            'VAT': s.vat,
                            'Grand Total': s.grandTotal,
                            'Customer': s.customerName,
                            'Salesperson': s.salesperson,
                            'Payment': s.paymentMethod
                        });
                    });
                });
            } else {
                sheetData = records.map(t => ({
                    'Date': t.date,
                    'Item': t.itemName,
                    'Category': t.category,
                    'Reason': t.reason,
                    'Quantity': t.quantity,
                    'Unit': t.unit,
                    'Value Lost (ETB)': t.valueLost,
                    'Responsible': t.responsible,
                    'Notes': t.notes || ''
                }));
            }

            const ws = XLSX.utils.json_to_sheet(sheetData);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, exportType.toUpperCase());
            XLSX.writeFile(wb, `${filename}.xlsx`);
            this.showToast(`Exported ${records.length} records to Excel (.xlsx) successfully`, 'success');
        } else {
            // Formatted Word document (.doc)
            let tableHeaders = '';
            let tableRows = '';

            if (exportType === 'inventory') {
                tableHeaders = '<th>Item ID</th><th>Generic Name</th><th>Category</th><th>Display Qty</th><th>Display Unit</th><th>Selling Price</th><th>Total Value</th><th>Batch</th><th>Expiry</th>';
                tableRows = records.map(i => `
                    <tr>
                        <td>${i.customId}</td><td>${this.escapeHtml(i.name)}</td><td>${i.category}</td>
                        <td>${i.quantityDisplay.toFixed(2)}</td><td>${i.displayUnit}</td>
                        <td>ETB ${i.sellingPricePerDisplay.toFixed(2)}</td>
                        <td>ETB ${(i.quantityDisplay * i.sellingPricePerDisplay).toFixed(2)}</td>
                        <td>${i.batchNumber}</td><td>${i.expiryDate}</td>
                    </tr>
                `).join('');
            } else if (exportType === 'sales') {
                tableHeaders = '<th>Date</th><th>Invoice</th><th>Customer</th><th>Grand Total</th><th>Salesperson</th><th>Payment</th>';
                tableRows = records.map(s => `
                    <tr>
                        <td>${s.date}</td><td>${s.invoiceNumber}</td><td>${s.customerName}</td>
                        <td>ETB ${s.grandTotal.toFixed(2)}</td><td>${s.salesperson}</td><td>${s.paymentMethod}</td>
                    </tr>
                `).join('');
            } else {
                tableHeaders = '<th>Date</th><th>Item</th><th>Reason</th><th>Qty</th><th>Unit</th><th>Value Lost</th><th>Responsible</th>';
                tableRows = records.map(t => `
                    <tr>
                        <td>${t.date}</td><td>${this.escapeHtml(t.itemName)}</td><td>${t.reason}</td>
                        <td>${t.quantity.toFixed(2)}</td><td>${t.unit}</td><td>ETB ${(t.valueLost || 0).toFixed(2)}</td><td>${t.responsible}</td>
                    </tr>
                `).join('');
            }

            const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${filename}</title><style>body{font-family:'Times New Roman',serif;margin:40px;}h1,h2{color:#0a1f3d;}table{border-collapse:collapse;width:100%;margin-top:20px;}th,td{border:1px solid #ddd;padding:8px;text-align:left;}th{background-color:#ffd700;color:#0a1f3d;}</style></head><body><h1>Eras-Birhan Pharmaceuticals (EBP-SMS)</h1><h2>${exportType.toUpperCase()} REPORT</h2><p>Generated: ${new Date().toLocaleString()} | Branch: ${this.currentBranch}</p><table><thead><tr>${tableHeaders}</tr></thead><tbody>${tableRows}</tbody></table></body></html>`;

            const blob = new Blob([html], { type: 'application/msword' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${filename}.doc`;
            a.click();
            URL.revokeObjectURL(url);
            this.showToast(`Exported ${records.length} records to Word (.doc) successfully`, 'success');
        }
    }

    // ============================================================
    // REQUIREMENT 7: AUTHENTICATION & HEADER FIXES
    // ============================================================
    handleLogin() {
        const typeSelect = document.getElementById('loginType') as HTMLSelectElement;
        const passInput = document.getElementById('password') as HTMLInputElement;
        const type = typeSelect?.value as 'admin' | 'user';
        const password = passInput?.value;

        if (!type) {
            this.showToast('Please select login type (User or Admin)', 'warning');
            return;
        }

        let valid = false;
        if (type === 'admin') {
            valid = password === this.settings.adminPassword;
        } else {
            const storedUserPass = localStorage.getItem('ebp-sms-user-password');
            if (!storedUserPass) {
                localStorage.setItem('ebp-sms-user-password', password);
                valid = true;
            } else {
                valid = password === storedUserPass || password === this.settings.userPassword;
            }
        }

        if (valid) {
            this.isLoggedIn = true;
            this.currentUserType = type;

            document.querySelectorAll('.admin-only').forEach(el => {
                (el as HTMLElement).style.display = type === 'admin' ? 'flex' : 'none';
            });

            document.querySelectorAll('.editable-text').forEach(el => {
                if (type === 'admin') el.classList.add('admin-mode');
                else el.classList.remove('admin-mode');
            });

            const welcomePage = document.getElementById('welcomePage');
            const mainContainer = document.getElementById('mainContainer');

            if (welcomePage) {
                welcomePage.style.opacity = '0';
                setTimeout(() => {
                    welcomePage.style.display = 'none';
                    welcomePage.style.pointerEvents = 'none';
                }, 300);
            }

            if (mainContainer) {
                mainContainer.style.display = 'block';
                mainContainer.style.pointerEvents = 'auto';
            }

            this.recordAudit('login', 0, 'System', 0, 'login', this.currentBranch, type);
            this.showToast(`Welcome! Logged in as ${type.toUpperCase()}`, 'success');
        } else {
            this.showToast('Invalid password for selected role', 'danger');
        }
    }

    // ============================================================
    // REVIEW DASHBOARD ANALYTICS & CHARTS (100% Offline)
    // ============================================================
    updateReviewDashboard() {
        const items = this.stockItems.filter(i => i.branch === this.currentBranch);
        const { start, end } = this.getFilteredDateRange('review');
        const periodSales = this.salesData.filter(s => s.branch === this.currentBranch && new Date(s.date) >= start && new Date(s.date) <= end);

        const totalItems = items.length;
        const totalSales = periodSales.reduce((sum, s) => sum + s.grandTotal, 0);
        const lowStock = items.filter(i => i.quantityDisplay > 0 && i.quantityDisplay < i.minStockDisplay).length;
        const reorderItems = items.filter(i => i.quantityDisplay <= i.reorderLevelDisplay && i.quantityDisplay > 0).length;

        const now = new Date();
        const nearExpiry = items.filter(i => {
            const diff = Math.ceil((new Date(i.expiryDate).getTime() - now.getTime()) / 86400000);
            return diff > 0 && diff <= 90;
        }).length;
        const expiredItems = items.filter(i => new Date(i.expiryDate).getTime() < now.getTime()).length;

        const inventoryValue = items.reduce((sum, i) => sum + (i.quantityDisplay * i.sellingPricePerDisplay), 0);
        const fastMoving = items.filter(i => i.movement === 'fast').length;
        const slowMoving = items.filter(i => i.movement === 'slow').length;

        const totalCOGS = periodSales.reduce((sum, s) => sum + (s.cogs || 0), 0);
        const grossProfit = totalSales - totalCOGS;

        const totalLoss = this.transactions
            .filter(t => t.branch === this.currentBranch && ['damaged', 'expired', 'theft'].includes(t.reason) && new Date(t.date) >= start && new Date(t.date) <= end)
            .reduce((sum, t) => sum + (t.valueLost || 0), 0);

        const netProfit = grossProfit - totalLoss;
        const turnover = totalCOGS > 0 ? (totalCOGS / Math.max(1, inventoryValue * 0.7)) : 0;

        let accurateCount = 0;
        items.forEach(i => {
            const expected = (i.beginningBalance || i.quantityDisplay) + (i.quantityReceived || i.quantityDisplay) - (i.quantityIssued || 0);
            const physical = i.physicalCount !== undefined ? i.physicalCount : i.quantityDisplay;
            if (Math.abs(physical - expected) <= 0.01) accurateCount++;
        });
        const accuracy = items.length > 0 ? (accurateCount / items.length * 100) : 100;

        document.getElementById('totalStockItems')!.textContent = totalItems.toString();
        document.getElementById('totalSales')!.innerHTML = `ETB ${totalSales.toFixed(2)}`;
        document.getElementById('lowStockItems')!.textContent = lowStock.toString();
        document.getElementById('reorderItems')!.textContent = reorderItems.toString();
        document.getElementById('nearExpiryItems')!.textContent = nearExpiry.toString();
        document.getElementById('expiredItems')!.textContent = expiredItems.toString();
        document.getElementById('totalInventoryValue')!.innerHTML = `ETB ${inventoryValue.toFixed(2)}`;
        document.getElementById('fastMovingItems')!.textContent = fastMoving.toString();
        document.getElementById('slowMovingItems')!.textContent = slowMoving.toString();
        document.getElementById('netProfit')!.innerHTML = `ETB ${netProfit.toFixed(2)}`;
        document.getElementById('grossProfit')!.innerHTML = `ETB ${grossProfit.toFixed(2)}`;
        document.getElementById('inventoryTurnover')!.textContent = turnover.toFixed(2);
        document.getElementById('stockAccuracy')!.innerHTML = `${accuracy.toFixed(1)}%`;
        const dupAcc = document.getElementById('stockAccuracyDuplicate');
        if (dupAcc) dupAcc.innerHTML = `${accuracy.toFixed(1)}%`;

        const forecast30 = (totalSales / Math.max(1, Math.ceil((end.getTime() - start.getTime()) / 86400000))) * 30;
        document.getElementById('demandForecast')!.innerHTML = `ETB ${forecast30.toFixed(2)} (Estimated next 30 days)`;

        const reorderList = items.filter(i => i.quantityDisplay <= i.reorderLevelDisplay && i.quantityDisplay > 0);
        document.getElementById('reorderRecommendations')!.innerHTML = reorderList.length > 0 ? `${reorderList.length} items need reorder` : 'All items sufficiently stocked';

        this.updateCharts();
        this.renderExpiryWastageReport();
        this.updateTopItems();
    }

    updateCharts() {
        Object.keys(this.charts).forEach(key => {
            if (this.charts[key]) {
                this.charts[key].destroy();
                delete this.charts[key];
            }
        });

        const ctx1 = document.getElementById('stockMovementChart') as HTMLCanvasElement;
        const ctx2 = document.getElementById('salesTrendChart') as HTMLCanvasElement;
        const ctx3 = document.getElementById('profitChart') as HTMLCanvasElement;
        const ctx4 = document.getElementById('movementChart') as HTMLCanvasElement;

        if (ctx1) {
            this.charts.stockMovement = new Chart(ctx1, {
                type: 'line',
                data: {
                    labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                    datasets: [{
                        label: 'Inventory Turnover',
                        data: [45, 60, 52, 70],
                        borderColor: '#00ff88',
                        tension: 0.3
                    }]
                }
            });
        }

        if (ctx2) {
            this.charts.salesTrend = new Chart(ctx2, {
                type: 'bar',
                data: {
                    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    datasets: [{
                        label: 'Daily Sales (ETB)',
                        data: [2500, 3200, 4100, 2900, 5600, 6800, 4900],
                        backgroundColor: '#ffd700'
                    }]
                }
            });
        }

        if (ctx3) {
            const gross = parseFloat(document.getElementById('grossProfit')?.innerText.replace('ETB ', '') || '1000');
            const net = Math.max(0, parseFloat(document.getElementById('netProfit')?.innerText.replace('ETB ', '') || '800'));
            const loss = Math.max(0, gross - net);

            this.charts.profitChart = new Chart(ctx3, {
                type: 'doughnut',
                data: {
                    labels: ['Net Profit', 'Loss/Deductions'],
                    datasets: [{
                        data: [net, loss],
                        backgroundColor: ['#00ff88', '#ff4444']
                    }]
                }
            });
        }

        if (ctx4) {
            const fast = this.stockItems.filter(i => i.movement === 'fast').length;
            const slow = this.stockItems.filter(i => i.movement === 'slow').length;
            const normal = Math.max(0, this.stockItems.length - fast - slow);

            this.charts.movementChart = new Chart(ctx4, {
                type: 'pie',
                data: {
                    labels: ['Fast Moving', 'Normal', 'Slow Moving'],
                    datasets: [{
                        data: [fast || 1, normal || 1, slow || 1],
                        backgroundColor: ['#00ff88', '#ffd700', '#ffaa00']
                    }]
                }
            });
        }
    }

    renderExpiryWastageReport() {
        const tbody = document.getElementById('expiryWastageBody');
        const footer = document.getElementById('expiryFooter');
        if (!tbody) return;

        const now = new Date();
        const expiring = this.stockItems
            .filter(i => {
                const diff = Math.ceil((new Date(i.expiryDate).getTime() - now.getTime()) / 86400000);
                return diff <= 90 && diff > 0;
            })
            .sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());

        let potentialLoss = 0;
        tbody.innerHTML = expiring.map(i => {
            const diff = Math.ceil((new Date(i.expiryDate).getTime() - now.getTime()) / 86400000);
            const loss = i.quantityDisplay * i.purchasePricePerDisplay;
            potentialLoss += loss;
            const statusClass = diff <= 30 ? 'status-critical' : 'status-warning';

            return `<tr>
                <td><strong>${this.escapeHtml(i.name)}</strong></td>
                <td>${i.batchNumber}</td>
                <td>${i.expiryDate}</td>
                <td><strong>${diff} days</strong></td>
                <td>${i.quantityDisplay.toFixed(2)} ${i.displayUnit}</td>
                <td class="variance-negative">ETB ${loss.toFixed(2)}</td>
                <td><span class="status-indicator ${statusClass}"></span> ${diff <= 30 ? 'URGENT' : 'WARNING'}</td>
            </tr>`;
        }).join('') || '<tr><td colspan="7" style="text-align:center;">No items near expiry (≤90 days)</td></tr>';

        if (footer) {
            footer.innerHTML = `<tr class="total-row"><td colspan="5" style="text-align:right;">Total Potential Expiry Loss:</td><td colspan="2" class="variance-negative">ETB ${potentialLoss.toFixed(2)}</td></tr>`;
        }
    }

    updateTopItems() {
        const tbody = document.getElementById('topItemsBody');
        if (!tbody) return;

        const itemSales: Record<number, { qty: number; revenue: number; profit: number }> = {};
        this.salesData.forEach(sale => {
            sale.items?.forEach((i: any) => {
                if (!itemSales[i.id]) itemSales[i.id] = { qty: 0, revenue: 0, profit: 0 };
                itemSales[i.id].qty += i.displayQuantity || i.inputQuantity || 0;
                itemSales[i.id].revenue += i.netAmount || 0;
            });
        });

        const sorted = Object.entries(itemSales).map(([idStr, val]) => {
            const item = this.stockItems.find(i => i.id === parseInt(idStr));
            return {
                name: item ? item.name : `Item #${idStr}`,
                category: item ? item.category : '-',
                type: item ? item.type : '-',
                ...val,
                margin: val.revenue > 0 ? 30 : 0
            };
        }).sort((a, b) => b.revenue - a.revenue);

        tbody.innerHTML = sorted.slice(0, 15).map(s => `
            <tr>
                <td><strong>${this.escapeHtml(s.name)}</strong></td>
                <td>${s.category}</td>
                <td>${s.type}</td>
                <td>${s.qty.toFixed(2)}</td>
                <td>ETB ${s.revenue.toFixed(2)}</td>
                <td>ETB ${(s.revenue * 0.3).toFixed(2)}</td>
                <td>30%</td>
            </tr>
        `).join('') || '<tr><td colspan="7" style="text-align:center;">No sales recorded yet</td></tr>';
    }

    renderDemandForecastDetail() {
        const tbody = document.getElementById('demandForecastTableBody');
        if (!tbody) return;

        const items = this.stockItems.filter(i => i.branch === this.currentBranch);
        tbody.innerHTML = items.slice(0, 30).map(i => {
            const daily = i.movement === 'fast' ? 5 : i.movement === 'slow' ? 0.3 : 1.5;
            const forecast30 = daily * 30;
            const coverage = i.quantityDisplay > 0 ? (i.quantityDisplay / daily) : 0;
            const recommended = Math.max(0, i.reorderLevelDisplay * 2 - i.quantityDisplay);

            return `<tr>
                <td>${this.escapeHtml(i.name)}</td>
                <td>${daily.toFixed(2)} ${i.displayUnit}</td>
                <td>${forecast30.toFixed(2)} ${i.displayUnit}</td>
                <td>${i.quantityDisplay.toFixed(2)}</td>
                <td>${coverage.toFixed(1)} days</td>
                <td><strong>${recommended.toFixed(2)}</strong></td>
            </tr>`;
        }).join('');
    }

    renderReorderDetail() {
        const tbody = document.getElementById('reorderDetailTableBody');
        if (!tbody) return;

        const needed = this.stockItems.filter(i => i.branch === this.currentBranch && i.quantityDisplay <= i.reorderLevelDisplay);
        tbody.innerHTML = needed.map(i => {
            const suggested = Math.max(10, i.reorderLevelDisplay * 2 - i.quantityDisplay);
            const urgency = i.quantityDisplay <= i.minStockDisplay ? 'CRITICAL' : 'MEDIUM';
            return `<tr>
                <td>${this.escapeHtml(i.name)}</td>
                <td style="color:var(--danger); font-weight:bold;">${i.quantityDisplay.toFixed(2)} ${i.displayUnit}</td>
                <td>${i.reorderLevelDisplay} ${i.displayUnit}</td>
                <td>${suggested.toFixed(2)} ${i.displayUnit}</td>
                <td><span class="status-indicator ${urgency === 'CRITICAL' ? 'status-critical' : 'status-warning'}"></span> ${urgency}</td>
            </tr>`;
        }).join('') || '<tr><td colspan="5" style="text-align:center;">No reorder needed currently</td></tr>';
    }

    renderLossReasonsTable() {
        const tbody = document.getElementById('lossReasonsBody');
        if (!tbody) return;

        const lossData = this.calculateLossByReason();
        tbody.innerHTML = lossData.map(l => `
            <tr>
                <td><span class="status-indicator status-critical"></span> ${l.reason}</td>
                <td>${l.quantity.toFixed(2)}</td>
                <td class="variance-negative">ETB ${l.value.toFixed(2)}</td>
                <td>${l.percentage.toFixed(1)}%</td>
            </tr>
        `).join('') || '<tr><td colspan="4" style="text-align:center;">No losses recorded</td></tr>';
    }

    renderCostSellingComparison() {
        const tbody = document.getElementById('costSellingBody');
        if (!tbody) return;

        const items = this.stockItems.filter(i => i.branch === this.currentBranch);
        tbody.innerHTML = items.slice(0, 30).map(i => {
            const profit = i.sellingPricePerDisplay - i.purchasePricePerDisplay;
            const margin = i.sellingPricePerDisplay > 0 ? (profit / i.sellingPricePerDisplay) * 100 : 0;
            return `<tr>
                <td>${this.escapeHtml(i.name)}</td>
                <td>ETB ${i.purchasePricePerDisplay.toFixed(2)}</td>
                <td>ETB ${i.sellingPricePerDisplay.toFixed(2)}</td>
                <td>${i.markup}%</td>
                <td class="variance-positive">ETB ${profit.toFixed(2)}</td>
                <td>${margin.toFixed(1)}%</td>
            </tr>`;
        }).join('');
    }

    renderVarianceTracking() {
        const tbody = document.getElementById('varianceTrackingBody');
        if (!tbody) return;

        const list = this.stockItems.filter(i => i.branch === this.currentBranch && i.variance !== 0);
        tbody.innerHTML = list.map(i => `
            <tr>
                <td>${this.escapeHtml(i.name)}</td>
                <td>${(i.endingBalance || i.quantityDisplay).toFixed(2)} ${i.displayUnit}</td>
                <td>${(i.physicalCount || i.quantityDisplay).toFixed(2)} ${i.displayUnit}</td>
                <td class="${i.variance >= 0 ? 'variance-positive' : 'variance-negative'}">${i.variance >= 0 ? '+' : ''}${i.variance.toFixed(2)}</td>
                <td class="${i.variance >= 0 ? 'variance-positive' : 'variance-negative'}">ETB ${(Math.abs(i.variance) * i.sellingPricePerDisplay).toFixed(2)}</td>
                <td>${i.variance >= 0 ? 'Surplus' : 'Shortage'}</td>
            </tr>
        `).join('') || '<tr><td colspan="6" style="text-align:center;">No variance recorded across inventory</td></tr>';
    }

    // ============================================================
    // AUDIT PAGE FUNCTIONALITY
    // ============================================================
    renderAuditTable() {
        const tbody = document.getElementById('auditTableBody');
        if (!tbody) return;

        const search = (document.getElementById('searchAudit') as HTMLInputElement)?.value.toLowerCase() || '';
        const typeFilter = (document.getElementById('auditTypeFilter') as HTMLSelectElement)?.value;
        const dateFilter = (document.getElementById('auditDateFilter') as HTMLSelectElement)?.value;

        let filtered = [...this.auditTrail];
        if (search) filtered = filtered.filter(a => a.action.toLowerCase().includes(search) || a.itemName?.toLowerCase().includes(search));
        if (typeFilter) filtered = filtered.filter(a => a.eventType === typeFilter);

        const now = new Date();
        if (dateFilter === 'today') filtered = filtered.filter(a => new Date(a.timestamp).toDateString() === now.toDateString());
        else if (dateFilter === 'week') filtered = filtered.filter(a => new Date(a.timestamp) >= new Date(now.getTime() - 7 * 86400000));
        else if (dateFilter === 'month') filtered = filtered.filter(a => new Date(a.timestamp) >= new Date(now.getTime() - 30 * 86400000));

        tbody.innerHTML = filtered.slice(0, 100).map(a => `
            <tr>
                <td>${new Date(a.timestamp).toLocaleString()}</td>
                <td><strong>${a.eventType || a.action}</strong></td>
                <td>${this.escapeHtml(a.itemName || '-')}</td>
                <td>${a.details?.category || '-'}</td>
                <td>${a.details?.type || '-'}</td>
                <td>${a.details?.baseUnit || '-'}</td>
                <td>${a.details?.regUnit || '-'}</td>
                <td>${a.details?.displayUnit || '-'}</td>
                <td>${a.user}</td>
                <td>${a.quantity || 0}</td>
                <td>ETB ${(a.details?.value || 0).toFixed(2)}</td>
                <td>${a.details?.batch || '-'}</td>
                <td>${a.details?.expiry || '-'}</td>
                <td>${a.details?.invoice || '-'}</td>
                <td>${a.branch}</td>
                <td><small>${typeof a.details === 'object' ? JSON.stringify(a.details).substring(0, 60) : a.details || ''}</small></td>
            </tr>
        `).join('') || '<tr><td colspan="16" style="text-align:center;">No audit records found</td></tr>';
    }

    updateAuditSummary() {
        const items = this.stockItems.filter(i => i.branch === this.currentBranch);
        let beginning = 0;
        let onHand = 0;
        let posVarItems = 0;
        let negVarItems = 0;
        let posCost = 0;
        let negCost = 0;

        items.forEach(i => {
            const beg = (i.beginningBalance || i.quantityDisplay) * i.sellingPricePerDisplay;
            const end = i.quantityDisplay * i.sellingPricePerDisplay;
            beginning += beg;
            onHand += end;

            if (i.variance > 0) {
                posVarItems++;
                posCost += i.variance * i.sellingPricePerDisplay;
            } else if (i.variance < 0) {
                negVarItems++;
                negCost += Math.abs(i.variance) * i.sellingPricePerDisplay;
            }
        });

        const netVariance = posCost - negCost;

        document.getElementById('auditBeginningBalance')!.textContent = `ETB ${beginning.toFixed(2)}`;
        document.getElementById('auditStockOnHandValue')!.textContent = `ETB ${onHand.toFixed(2)}`;
        document.getElementById('auditEndingBalance')!.textContent = `ETB ${onHand.toFixed(2)}`;
        document.getElementById('auditPosVarItems')!.textContent = posVarItems.toString();
        document.getElementById('auditNegVarItems')!.textContent = negVarItems.toString();
        document.getElementById('auditPosVarCost')!.textContent = `ETB ${posCost.toFixed(2)}`;
        document.getElementById('auditNegVarCost')!.textContent = `ETB ${negCost.toFixed(2)}`;
        document.getElementById('auditNetVariance')!.textContent = `ETB ${netVariance.toFixed(2)}`;
        document.getElementById('auditAccuracy')!.textContent = `${items.length > 0 ? (((items.length - (posVarItems + negVarItems)) / items.length) * 100).toFixed(1) : 100}%`;
    }

    renderAuditVarianceDetail() {
        const tbody = document.getElementById('auditVarianceDetailBody');
        if (!tbody) return;

        const variances = this.stockItems.filter(i => i.branch === this.currentBranch && i.variance !== 0);
        tbody.innerHTML = variances.map(i => `
            <tr>
                <td><strong>${this.escapeHtml(i.name)}</strong></td>
                <td>${(i.endingBalance || i.quantityDisplay).toFixed(2)} ${i.displayUnit}</td>
                <td>${(i.physicalCount || i.quantityDisplay).toFixed(2)} ${i.displayUnit}</td>
                <td class="${i.variance >= 0 ? 'variance-positive' : 'variance-negative'}">${i.variance >= 0 ? '+' : ''}${i.variance.toFixed(2)}</td>
                <td class="${i.variance >= 0 ? 'variance-positive' : 'variance-negative'}">ETB ${(Math.abs(i.variance) * i.sellingPricePerDisplay).toFixed(2)}</td>
                <td>${i.variance >= 0 ? 'Surplus' : 'Shortage'}</td>
            </tr>
        `).join('') || '<tr><td colspan="6" style="text-align:center;">No item variances found</td></tr>';
    }

    updateAuditWithNetProfit() {
        const { start, end } = this.getFilteredDateRange('audit');
        const periodSales = this.salesData.filter(s => s.branch === this.currentBranch && new Date(s.date) >= start && new Date(s.date) <= end);
        const revenue = periodSales.reduce((sum, s) => sum + s.grandTotal, 0);
        const cogs = periodSales.reduce((sum, s) => sum + (s.cogs || 0), 0);
        const gross = revenue - cogs;

        const losses = this.transactions
            .filter(t => t.branch === this.currentBranch && ['damaged', 'expired', 'theft'].includes(t.reason) && new Date(t.date) >= start && new Date(t.date) <= end)
            .reduce((sum, t) => sum + (t.valueLost || 0), 0);

        const net = gross - losses;

        const netProfitEl = document.getElementById('auditNetProfit');
        const grossPLEl = document.getElementById('auditGrossPL');
        if (netProfitEl) netProfitEl.textContent = `ETB ${net.toFixed(2)}`;
        if (grossPLEl) grossPLEl.textContent = `ETB ${gross.toFixed(2)}`;
    }

    // ============================================================
    // SALES HISTORY, ACTIVITY LOG & MISC
    // ============================================================
    renderSalesHistory() {
        const tbody = document.getElementById('salesHistoryBody');
        const footer = document.getElementById('salesHistoryFooter');
        if (!tbody) return;

        let filtered = [...this.salesData].filter(s => s.branch === this.currentBranch);
        const search = (document.getElementById('salesHistorySearch') as HTMLInputElement)?.value.toLowerCase() || '';
        if (search) filtered = filtered.filter(s => s.customerName?.toLowerCase().includes(search) || s.invoiceNumber?.toLowerCase().includes(search));

        const startIdx = (this.salesHistoryPage - 1) * this.salesHistoryRowsPerPage;
        const pageItems = filtered.slice(startIdx, startIdx + this.salesHistoryRowsPerPage);

        let totalGrand = 0;
        let totalProfit = 0;

        tbody.innerHTML = pageItems.map(sale => {
            totalGrand += sale.grandTotal;
            totalProfit += sale.profit || 0;

            return sale.items?.map((item: any) => `
                <tr>
                    <td>${sale.date}</td>
                    <td>${sale.invoiceNumber}</td>
                    <td><strong>${this.escapeHtml(item.name)}</strong></td>
                    <td>${item.category || '-'}</td>
                    <td>${item.type || '-'}</td>
                    <td>${(item.inputQuantity || item.displayQuantity).toFixed(2)}</td>
                    <td>${item.unitLabel}</td>
                    <td>ETB ${item.unitPrice.toFixed(2)}</td>
                    <td>ETB ${item.netAmount.toFixed(2)}</td>
                    <td>${item.markup || 50}%</td>
                    <td>ETB ${(sale.totalDiscount || 0).toFixed(2)}</td>
                    <td>ETB ${(sale.vat || 0).toFixed(2)}</td>
                    <td>ETB ${sale.grandTotal.toFixed(2)}</td>
                    <td>ETB ${(sale.profit || 0).toFixed(2)}</td>
                    <td>${(sale.margin || 0).toFixed(1)}%</td>
                    <td>${sale.customerName || '-'}</td>
                    <td>${sale.paymentMethod}</td>
                    <td>${sale.salesperson}</td>
                </tr>
            `).join('') || '';
        }).join('') || '<tr><td colspan="18" style="text-align:center;">No sales records found</td></tr>';

        if (footer) {
            footer.innerHTML = `<tr class="total-row"><td colspan="8" style="text-align:right;">TOTAL:</td><td>ETB ${totalGrand.toFixed(2)}</td><td colspan="4"></td><td>ETB ${totalProfit.toFixed(2)}</td><td colspan="4"></td></tr>`;
        }

        const totalPages = Math.ceil(filtered.length / this.salesHistoryRowsPerPage);
        const pagDiv = document.getElementById('salesHistoryPagination');
        if (pagDiv) {
            let html = '';
            for (let i = 1; i <= Math.min(totalPages, 10); i++) {
                html += `<button class="page-btn ${i === this.salesHistoryPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
            }
            pagDiv.innerHTML = html;
            pagDiv.querySelectorAll('.page-btn').forEach(b => {
                b.addEventListener('click', () => {
                    this.salesHistoryPage = parseInt((b as HTMLElement).dataset.page!);
                    this.renderSalesHistory();
                });
            });
        }
    }

    renderActivityLog() {
        const tbody = document.getElementById('activityLogBody');
        if (!tbody) return;

        const search = (document.getElementById('activitySearch') as HTMLInputElement)?.value.toLowerCase() || '';
        const typeFilter = (document.getElementById('activityTypeFilter') as HTMLSelectElement)?.value;

        let filtered = [...this.auditTrail];
        if (search) filtered = filtered.filter(a => a.action.toLowerCase().includes(search) || a.itemName?.toLowerCase().includes(search));
        if (typeFilter) filtered = filtered.filter(a => a.eventType === typeFilter);

        tbody.innerHTML = filtered.slice(0, 100).map(a => `
            <tr>
                <td>${new Date(a.timestamp).toLocaleString()}</td>
                <td><strong>${a.action}</strong></td>
                <td>${a.user}</td>
                <td>${this.escapeHtml(a.itemName || '-')}</td>
                <td><small>${typeof a.details === 'object' ? JSON.stringify(a.details).substring(0, 60) : a.details || ''}</small></td>
                <td>${a.branch}</td>
            </tr>
        `).join('') || '<tr><td colspan="6" style="text-align:center;">No activity records</td></tr>';
    }

    calculateLossByReason() {
        const losses: Record<string, { quantity: number; value: number }> = {};
        let totalVal = 0;

        this.transactions.forEach(t => {
            if (['damaged', 'expired', 'theft', 'other'].includes(t.reason)) {
                if (!losses[t.reason]) losses[t.reason] = { quantity: 0, value: 0 };
                losses[t.reason].quantity += t.quantity;
                losses[t.reason].value += t.valueLost || 0;
                totalVal += t.valueLost || 0;
            }
        });

        return Object.entries(losses).map(([reason, data]) => ({
            reason: reason.charAt(0).toUpperCase() + reason.slice(1),
            quantity: data.quantity,
            value: data.value,
            percentage: totalVal > 0 ? (data.value / totalVal) * 100 : 0
        })).sort((a, b) => b.value - a.value);
    }

    showTotalLossModal() {
        const modal = document.getElementById('totalLossModal');
        const lossReasons = this.calculateLossByReason();
        const reportBody = document.getElementById('lossReportBody');
        const detailBody = document.getElementById('lossDetailBody');

        if (reportBody) {
            reportBody.innerHTML = lossReasons.map(r => `
                <tr>
                    <td>${r.reason}</td>
                    <td>${r.quantity.toFixed(2)}</td>
                    <td>ETB ${r.value.toFixed(2)}</td>
                    <td>${r.percentage.toFixed(1)}%</td>
                </tr>
            `).join('') || '<tr><td colspan="4">No losses recorded</td></tr>';
        }

        if (detailBody) {
            const lossList = this.transactions.filter(t => ['damaged', 'expired', 'theft'].includes(t.reason));
            detailBody.innerHTML = lossList.map(l => `
                <tr>
                    <td>${this.escapeHtml(l.itemName)}</td>
                    <td>${l.batch}</td>
                    <td>${l.reason}</td>
                    <td>${l.quantity.toFixed(2)}</td>
                    <td>ETB ${(l.valueLost || 0).toFixed(2)}</td>
                    <td>${l.date}</td>
                </tr>
            `).join('') || '<tr><td colspan="6">No loss details</td></tr>';
        }

        if (modal) modal.classList.add('active');
        document.getElementById('totalLossModalExit')?.addEventListener('click', () => modal?.classList.remove('active'));
        document.getElementById('closeLossModalBtn')?.addEventListener('click', () => modal?.classList.remove('active'));
    }

    // ============================================================
    // TELEGRAM SHARING & MASKING
    // ============================================================
    openShareModal() {
        if (!this.isLoggedIn) {
            this.showToast('Please login first', 'warning');
            return;
        }
        this.selectedShareItems.clear();
        document.getElementById('shareModal')?.classList.add('active');
        this.updateShareCategoryFilter();
        this.renderShareTable();
        this.updateShareStats();
    }

    closeShareModal() {
        document.getElementById('shareModal')?.classList.remove('active');
        this.selectedShareItems.clear();
    }

    updateShareCategoryFilter() {
        const filter = document.getElementById('shareCategoryFilter') as HTMLSelectElement;
        if (!filter) return;
        const cats = [...new Set(this.stockItems.map(i => i.category).filter(Boolean))];
        filter.innerHTML = '<option value="">All Categories</option>' + cats.map(c => `<option value="${c}">${c}</option>`).join('');
    }

    renderShareTable() {
        const tbody = document.getElementById('shareTableBody');
        if (!tbody) return;

        let items = [...this.stockItems];
        const branchFilter = (document.getElementById('shareBranchFilter') as HTMLSelectElement)?.value;
        if (branchFilter && branchFilter !== 'all') items = items.filter(i => i.branch === branchFilter);

        const search = (document.getElementById('shareSearchInput') as HTMLInputElement)?.value.toLowerCase() || '';
        if (search) items = items.filter(i => i.name.toLowerCase().includes(search) || (i.brandName && i.brandName.toLowerCase().includes(search)));

        const category = (document.getElementById('shareCategoryFilter') as HTMLSelectElement)?.value;
        if (category) items = items.filter(i => i.category === category);

        // Sorting
        const sortMode = this.currentSort.share;
        if (sortMode === 'name-asc') items.sort((a, b) => a.name.localeCompare(b.name));
        else if (sortMode === 'name-desc') items.sort((a, b) => b.name.localeCompare(a.name));
        else items.sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());

        document.getElementById('shareTotalCount')!.textContent = items.length.toString();

        const maskUnitPrice = this.settings.maskUnitPrice;
        const maskTotalCost = this.settings.maskTotalCost;
        const maskSellingPrice = this.settings.maskSellingPrice;

        tbody.innerHTML = items.map(item => {
            const isSelected = this.selectedShareItems.has(item.id);
            const expiry = new Date(item.expiryDate);
            const diff = Math.ceil((expiry.getTime() - new Date().getTime()) / 86400000);
            const statusClass = diff < 0 ? 'status-expired' : diff <= 30 ? 'status-critical' : diff <= 90 ? 'status-warning' : 'status-ok';
            const statusText = diff < 0 ? 'Expired' : diff <= 30 ? 'Expiring Soon' : diff <= 90 ? 'Near Expiry' : 'Good';

            const unitPrice = maskUnitPrice ? '***' : `ETB ${item.sellingPricePerDisplay.toFixed(2)}`;
            const totalValue = maskTotalCost ? '***' : `ETB ${(item.quantityDisplay * item.sellingPricePerDisplay).toFixed(2)}`;
            const costPrice = maskUnitPrice ? '***' : `ETB ${item.purchasePricePerDisplay.toFixed(2)}`;
            const sellingPrice = maskSellingPrice ? '***' : `ETB ${item.sellingPricePerDisplay.toFixed(2)}`;

            return `<tr class="${isSelected ? 'selected' : ''}">
                <td class="checkbox-cell"><input type="checkbox" class="share-item-checkbox" data-id="${item.id}" ${isSelected ? 'checked' : ''}></td>
                <td><strong>${this.escapeHtml(item.name)}</strong></td>
                <td>${this.escapeHtml(item.brandName || '-')}</td>
                <td>${item.batchNumber}</td>
                <td>${item.baseUnit}</td>
                <td>${item.registeredUnit}</td>
                <td>${item.displayUnit}</td>
                <td>${item.quantityBase.toFixed(2)}</td>
                <td><strong>${item.quantityDisplay.toFixed(2)}</strong></td>
                <td>${unitPrice}</td>
                <td>${totalValue}</td>
                <td>${costPrice}</td>
                <td>${sellingPrice}</td>
                <td><span class="status-indicator ${statusClass}"></span> ${expiry.toLocaleDateString()}</td>
                <td>${statusText}</td>
            </tr>`;
        }).join('') || '<tr><td colspan="15" style="text-align:center;">No items found</td></tr>';

        document.querySelectorAll('.share-item-checkbox').forEach(cb => {
            cb.addEventListener('change', (e) => {
                const target = e.target as HTMLInputElement;
                const id = parseInt(target.dataset.id!);
                if (target.checked) this.selectedShareItems.add(id);
                else this.selectedShareItems.delete(id);
                this.updateShareStats();
            });
        });

        this.updateShareStats();
    }

    toggleSelectAllShares(select: boolean) {
        document.querySelectorAll('.share-item-checkbox').forEach(cb => {
            const box = cb as HTMLInputElement;
            box.checked = select;
            const id = parseInt(box.dataset.id!);
            if (select) this.selectedShareItems.add(id);
            else this.selectedShareItems.delete(id);
        });
        this.updateShareStats();
    }

    updateShareStats() {
        const count = this.selectedShareItems.size;
        document.getElementById('shareSelectedCount')!.textContent = count.toString();
        const selected = this.stockItems.filter(i => this.selectedShareItems.has(i.id));

        const now = new Date();
        const expiring = selected.filter(i => {
            const diff = Math.ceil((new Date(i.expiryDate).getTime() - now.getTime()) / 86400000);
            return diff > 0 && diff <= 90;
        }).length;
        const low = selected.filter(i => i.quantityDisplay < i.minStockDisplay && i.quantityDisplay > 0).length;

        document.getElementById('shareExpiringCount')!.textContent = expiring.toString();
        document.getElementById('shareLowStockCount')!.textContent = low.toString();
    }

    shareToTelegram() {
        const count = this.selectedShareItems.size;
        if (count === 0) {
            this.showToast('Please select at least one item to share', 'warning');
            return;
        }

        const sender = (document.getElementById('shareSenderName') as HTMLInputElement).value.trim();
        if (!sender) {
            this.showToast('Please enter your sender name and phone', 'warning');
            return;
        }

        const selected = this.stockItems.filter(i => this.selectedShareItems.has(i.id));
        let message = `🏥 *${this.settings.pharmacyName} (${this.settings.brandName})*\n`;
        message += `📋 *STOCK EXCHANGE INVENTORY REPORT*\n`;
        message += `👤 Sender: ${sender}\n`;
        message += `📅 Date: ${new Date().toLocaleDateString()}\n\n`;

        selected.forEach((i, idx) => {
            message += `${idx + 1}. *${i.name}* (${i.brandName || 'Generic'})\n`;
            message += `   Qty: ${i.quantityDisplay.toFixed(0)} ${i.displayUnit} | Batch: ${i.batchNumber} | Exp: ${i.expiryDate}\n`;
        });

        message += `\n📦 Total Shared Items: ${selected.length}\n🔒 Generated securely via EBP-SMS.`;

        const encoded = encodeURIComponent(message);
        this.recordShareHistory('@assegas', count, 'telegram', 'sent');

        // Open Telegram URL safely
        window.open(`https://t.me/share/url?url=&text=${encoded}`, '_blank');
        this.showToast(`Telegram message prepared for ${count} items`, 'success');
        this.closeShareModal();
    }

    copySharePreview() {
        const count = this.selectedShareItems.size;
        if (count === 0) {
            this.showToast('Select items first', 'warning');
            return;
        }
        const sender = (document.getElementById('shareSenderName') as HTMLInputElement).value.trim() || 'Staff';
        const selected = this.stockItems.filter(i => this.selectedShareItems.has(i.id));

        let message = `🏥 ${this.settings.pharmacyName} (${this.settings.brandName})\nSender: ${sender}\n\n`;
        selected.forEach((i, idx) => {
            message += `${idx + 1}. ${i.name} - Qty: ${i.quantityDisplay.toFixed(0)} ${i.displayUnit} (Exp: ${i.expiryDate})\n`;
        });

        navigator.clipboard.writeText(message).then(() => {
            this.showToast('Report copied to clipboard', 'success');
        }).catch(() => {
            this.showToast('Failed to copy to clipboard', 'warning');
        });
    }

    exportSelectedItems() {
        const count = this.selectedShareItems.size;
        if (count === 0) {
            this.showToast('Select items to export', 'warning');
            return;
        }

        const selected = this.stockItems.filter(i => this.selectedShareItems.has(i.id));
        const format = (document.getElementById('shareExportType') as HTMLSelectElement).value;

        if (format === 'csv') {
            let csv = "Generic Name,Brand,Batch,Display Qty,Display Unit,Expiry Date\n";
            selected.forEach(i => {
                csv += `"${i.name}","${i.brandName || ''}","${i.batchNumber}","${i.quantityDisplay}","${i.displayUnit}","${i.expiryDate}"\n`;
            });
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `shared_stock_${new Date().toISOString().slice(0, 10)}.csv`;
            a.click();
            URL.revokeObjectURL(url);
        } else {
            const dataStr = JSON.stringify(selected, null, 2);
            const blob = new Blob([dataStr], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `shared_stock_${new Date().toISOString().slice(0, 10)}.json`;
            a.click();
            URL.revokeObjectURL(url);
        }

        this.recordShareHistory('@assegas', count, format, 'exported');
        this.showToast(`Exported ${count} items successfully`, 'success');
    }

    recordShareHistory(recipient: string, itemCount: number, type: string, status: string) {
        const record = {
            id: Date.now(),
            date: new Date().toISOString(),
            recipient: recipient,
            itemCount: itemCount,
            type: type,
            status: status
        };
        this.shareHistory.unshift(record);
        if (this.shareHistory.length > 50) this.shareHistory.pop();
        this.saveToLocalStorage();
        this.renderShareHistory();
    }

    loadShareHistory() {
        this.renderShareHistory();
    }

    renderShareHistory() {
        const tbody = document.getElementById('shareHistoryBody');
        if (!tbody) return;
        tbody.innerHTML = this.shareHistory.map(h => `
            <tr>
                <td>${new Date(h.date).toLocaleString()}</td>
                <td>${h.recipient}</td>
                <td>${h.itemCount}</td>
                <td>${h.type.toUpperCase()}</td>
                <td><span class="status-indicator status-ok"></span> ${h.status}</td>
            </tr>
        `).join('') || '<tr><td colspan="5" style="text-align:center;">No share history</td></tr>';
    }

    // ============================================================
    // SETTINGS, BACKUP & RESTORE
    // ============================================================
    loadSettings() {
        (document.getElementById('lowStockThreshold') as HTMLInputElement).value = this.settings.lowStockThreshold;
        (document.getElementById('expiryWarningDays') as HTMLInputElement).value = this.settings.expiryWarningDays;
        (document.getElementById('defaultMarkup') as HTMLInputElement).value = this.settings.defaultMarkup;
        (document.getElementById('defaultVAT') as HTMLInputElement).value = this.settings.defaultVAT;
        (document.getElementById('overstockAlert') as HTMLInputElement).value = this.settings.overstockAlert;
        (document.getElementById('profitMarginAlert') as HTMLInputElement).value = this.settings.profitMarginAlert;
        (document.getElementById('baseUnitsList') as HTMLInputElement).value = this.settings.baseUnitsList;
        (document.getElementById('displayUnitsList') as HTMLInputElement).value = this.settings.displayUnitsList;
        (document.getElementById('registeredUnitsList') as HTMLInputElement).value = this.settings.registeredUnitsList;
        (document.getElementById('userPassword') as HTMLInputElement).value = this.settings.userPassword;
        (document.getElementById('adminPassword') as HTMLInputElement).value = this.settings.adminPassword;
        (document.getElementById('editPharmacyName') as HTMLInputElement).value = this.settings.pharmacyName;
        (document.getElementById('editBrandName') as HTMLInputElement).value = this.settings.brandName;
        (document.getElementById('maskUnitPrice') as HTMLInputElement).checked = this.settings.maskUnitPrice;
        (document.getElementById('maskTotalCost') as HTMLInputElement).checked = this.settings.maskTotalCost;
        (document.getElementById('maskSellingPrice') as HTMLInputElement).checked = this.settings.maskSellingPrice;
    }

    saveSettings() {
        this.settings.lowStockThreshold = parseInt((document.getElementById('lowStockThreshold') as HTMLInputElement).value) || 20;
        this.settings.expiryWarningDays = parseInt((document.getElementById('expiryWarningDays') as HTMLInputElement).value) || 30;
        this.settings.defaultMarkup = parseFloat((document.getElementById('defaultMarkup') as HTMLInputElement).value) || 50;
        this.settings.defaultVAT = parseFloat((document.getElementById('defaultVAT') as HTMLInputElement).value) || 15;
        this.settings.overstockAlert = parseInt((document.getElementById('overstockAlert') as HTMLInputElement).value) || 150;
        this.settings.profitMarginAlert = parseInt((document.getElementById('profitMarginAlert') as HTMLInputElement).value) || 10;
        this.settings.baseUnitsList = (document.getElementById('baseUnitsList') as HTMLInputElement).value;
        this.settings.displayUnitsList = (document.getElementById('displayUnitsList') as HTMLInputElement).value;
        this.settings.registeredUnitsList = (document.getElementById('registeredUnitsList') as HTMLInputElement).value;
        this.settings.userPassword = (document.getElementById('userPassword') as HTMLInputElement).value || "123456";
        this.settings.adminPassword = (document.getElementById('adminPassword') as HTMLInputElement).value || "kpi2123";
        this.settings.pharmacyName = (document.getElementById('editPharmacyName') as HTMLInputElement).value || "Eras-Birhan Pharmaceuticals";
        this.settings.brandName = (document.getElementById('editBrandName') as HTMLInputElement).value || "EBP-SMS";
        this.settings.maskUnitPrice = (document.getElementById('maskUnitPrice') as HTMLInputElement).checked;
        this.settings.maskTotalCost = (document.getElementById('maskTotalCost') as HTMLInputElement).checked;
        this.settings.maskSellingPrice = (document.getElementById('maskSellingPrice') as HTMLInputElement).checked;

        this.saveToLocalStorage();
        this.updateTextEdits();
        this.setupUnitLists();
        document.getElementById('settingsPanel')?.classList.remove('active');
        this.showToast('System settings saved successfully', 'success');
    }

    backupData() {
        const dump = {
            stockItems: this.stockItems,
            salesData: this.salesData,
            transactions: this.transactions,
            auditTrail: this.auditTrail,
            settings: this.settings,
            shareHistory: this.shareHistory,
            currentId: this.currentId,
            salesCounter: this.salesCounter,
            backupDate: new Date().toISOString()
        };

        const blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `ebp_backup_${new Date().toISOString().slice(0, 10)}.json`;
        a.click();
        URL.revokeObjectURL(url);
        this.showToast('Offline backup created successfully', 'success');
    }

    restoreData() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';

        input.onchange = (e: any) => {
            const file = e.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = (event: any) => {
                try {
                    const data = JSON.parse(event.target.result);
                    if (confirm('Restore backup? Existing local data will be replaced.')) {
                        this.stockItems = data.stockItems || [];
                        this.salesData = data.salesData || [];
                        this.transactions = data.transactions || [];
                        this.auditTrail = data.auditTrail || [];
                        this.settings = data.settings || this.settings;
                        this.shareHistory = data.shareHistory || [];
                        this.currentId = data.currentId || 1;
                        this.salesCounter = data.salesCounter || 1001;

                        this.saveToLocalStorage();
                        this.showToast('Data restored successfully. Reloading view...', 'success');
                        setTimeout(() => location.reload(), 800);
                    }
                } catch {
                    this.showToast('Invalid backup file. Restoration aborted.', 'danger');
                }
            };
            reader.readAsText(file);
        };

        input.click();
    }

    clearAllData() {
        if (prompt('Type "DELETE ALL" to confirm total reset:') === 'DELETE ALL') {
            localStorage.clear();
            sessionStorage.clear();
            this.showToast('All local storage data cleared', 'info');
            setTimeout(() => location.reload(), 500);
        }
    }

    // ============================================================
    // PERSISTENCE & LOCAL STORAGE
    // ============================================================
    loadFromLocalStorage() {
        try {
            const savedStock = localStorage.getItem('ebp-sms-stock');
            if (savedStock) {
                const parsed = JSON.parse(savedStock);
                this.stockItems = parsed.stockItems || [];
                this.currentId = parsed.currentId || 1;
            }

            const savedSales = localStorage.getItem('ebp-sms-sales');
            if (savedSales) this.salesData = JSON.parse(savedSales);

            const savedAudit = localStorage.getItem('ebp-sms-audit');
            if (savedAudit) this.auditTrail = JSON.parse(savedAudit);

            const savedTx = localStorage.getItem('ebp-sms-transactions');
            if (savedTx) this.transactions = JSON.parse(savedTx);

            const savedSettings = localStorage.getItem('ebp-sms-settings');
            if (savedSettings) this.settings = { ...this.settings, ...JSON.parse(savedSettings) };

            const savedShare = localStorage.getItem('ebp-sms-share-history');
            if (savedShare) this.shareHistory = JSON.parse(savedShare);

            this.auditCounter = this.auditTrail.length > 0 ? Math.max(...this.auditTrail.map(a => a.id || 0)) + 1 : 1;
        } catch (e) {
            console.error('Storage load error:', e);
        }
    }

    saveToLocalStorage() {
        const stockPayload = { stockItems: this.stockItems, currentId: this.currentId };
        this.integrityManager.saveWithChecksum('ebp-sms-stock', stockPayload);
        localStorage.setItem('ebp-sms-sales', JSON.stringify(this.salesData));
        localStorage.setItem('ebp-sms-audit', JSON.stringify(this.auditTrail));
        localStorage.setItem('ebp-sms-transactions', JSON.stringify(this.transactions));
        localStorage.setItem('ebp-sms-settings', JSON.stringify(this.settings));
        localStorage.setItem('ebp-sms-share-history', JSON.stringify(this.shareHistory));
        this.updateSyncStatus();
    }

    updateSyncStatus() {
        const timeEl = document.getElementById('lastSyncTime');
        const countEl = document.getElementById('pendingOps');
        if (timeEl) timeEl.textContent = new Date().toLocaleTimeString();
        if (countEl) countEl.textContent = `${this.stockItems.length} items`;
    }

    recordAudit(action: string, itemId: number, itemName: string, quantity: number, eventType: string, branch: string, user: string, details: any = {}) {
        const audit = {
            id: this.auditCounter++,
            action, itemId, itemName, quantity, eventType, branch, user, details,
            timestamp: new Date().toISOString()
        };
        this.auditTrail.unshift(audit);
        if (this.auditTrail.length > 1000) this.auditTrail.pop();
        this.saveToLocalStorage();
    }

    updateItemMovement(itemId: number, qtySold: number) {
        const item = this.stockItems.find(i => i.id === itemId);
        if (item) {
            if (!item.movementHistory) item.movementHistory = [];
            item.movementHistory.push({ date: new Date().toISOString(), qty: qtySold });
            const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000);
            const recent = item.movementHistory.filter((h: any) => new Date(h.date) >= thirtyDaysAgo);
            const total = recent.reduce((sum: number, h: any) => sum + h.qty, 0);
            const daily = total / 30;
            if (daily > 3) item.movement = 'fast';
            else if (daily < 0.3) item.movement = 'slow';
            else item.movement = 'normal';
        }
    }

    // ============================================================
    // UTILITIES, TOOLTIPS, BRANDING
    // ============================================================
    setupUnitLists() {
        const bList = document.getElementById('baseUnitList');
        const dList = document.getElementById('displayUnitList');
        const rList = document.getElementById('registeredUnitList');

        if (bList) bList.innerHTML = this.settings.baseUnitsList.split(',').map((u: string) => `<option value="${u.trim()}">`).join('');
        if (dList) dList.innerHTML = this.settings.displayUnitsList.split(',').map((u: string) => `<option value="${u.trim()}">`).join('');
        if (rList) rList.innerHTML = this.settings.registeredUnitsList.split(',').map((u: string) => `<option value="${u.trim()}">`).join('');
        this.updateDatalists();
    }

    updateDatalists() {
        const categories = [...new Set(this.stockItems.map(i => i.category).filter(Boolean))];
        const suppliers = [...new Set(this.stockItems.map(i => i.supplier).filter(Boolean))];
        const registrants = [...new Set(this.stockItems.map(i => i.registrant).filter(Boolean))];
        const batchNumbers = [...new Set(this.stockItems.map(i => i.batchNumber).filter(Boolean))];
        const brandNames = [...new Set(this.stockItems.map(i => i.brandName).filter(Boolean))];
        const itemIds = [...new Set(this.stockItems.map(i => i.customId).filter(Boolean))];

        this.setDatalist('categoryList', categories);
        this.setDatalist('supplierList', suppliers);
        this.setDatalist('registrantList', registrants);
        this.setDatalist('batchNumberList', batchNumbers);
        this.setDatalist('brandNameList', brandNames);
        this.setDatalist('existingItemIdsList', itemIds);
        this.setDatalist('customerNameList', [...new Set(this.salesData.map(s => s.customerName).filter(Boolean))]);
        this.setDatalist('salespersonList', [...new Set(this.salesData.map(s => s.salesperson).filter(Boolean))]);
    }

    setDatalist(id: string, values: string[]) {
        const el = document.getElementById(id);
        if (el) el.innerHTML = values.map(v => `<option value="${this.escapeHtml(v)}">`).join('');
    }

    updateItemNameList() {
        const datalist = document.getElementById('itemNameList');
        if (datalist) {
            const names = [...new Set(this.stockItems.map(i => i.name))];
            datalist.innerHTML = names.map(n => `<option value="${this.escapeHtml(n)}">`).join('');
        }
    }

    updateCategoryFilter() {
        const filter = document.getElementById('categoryFilter') as HTMLSelectElement;
        if (!filter) return;
        const cats = [...new Set(this.stockItems.map(i => i.category).filter(Boolean))];
        filter.innerHTML = '<option value="">All Categories</option>' + cats.map(c => `<option value="${c}">${c}</option>`).join('');
    }

    updateTextEdits() {
        const headerTitle = document.getElementById('mainHeaderTitle');
        const pharmacyHeader = document.getElementById('pharmacyHeaderName');
        const ownerName = document.getElementById('pharmacyOwnerName');
        const welcomeTitle = document.getElementById('welcomeTitle');
        const welcomeOwner = document.getElementById('welcomeOwner');

        if (headerTitle) headerTitle.innerText = `${this.settings.pharmacyName} Stock Management System (${this.settings.brandName})`;
        if (pharmacyHeader) pharmacyHeader.innerText = this.settings.pharmacyName;
        if (ownerName) ownerName.innerText = this.settings.brandName;
        if (welcomeTitle) welcomeTitle.innerText = `${this.settings.pharmacyName} Stock Management System (${this.settings.brandName})`;
        if (welcomeOwner) welcomeOwner.innerText = this.settings.brandName;
    }

    setupEditableText() {
        document.querySelectorAll('.editable-text').forEach(el => {
            el.addEventListener('click', () => {
                if (this.currentUserType !== 'admin') return;
                const newText = prompt('Edit branding title:', (el as HTMLElement).innerText);
                if (newText && newText.trim() !== '') {
                    (el as HTMLElement).innerText = newText.trim();
                    if (el.id === 'pharmacyHeaderName') this.settings.pharmacyName = newText.trim();
                    if (el.id === 'pharmacyOwnerName') this.settings.brandName = newText.trim();
                    this.saveToLocalStorage();
                    this.showToast('Branding updated successfully', 'success');
                }
            });
        });
    }

    applyButtonCustomizations() {
        const btns: Record<string, string> = {
            navRegisterStock: this.settings.buttonTexts?.register || 'Register',
            navSales: this.settings.buttonTexts?.sales || 'Sales',
            navCurrentStock: this.settings.buttonTexts?.inventory || 'Inventory',
            navReduceStock: this.settings.buttonTexts?.deduct || 'Deduct',
            navReview: this.settings.buttonTexts?.review || 'Review',
            navAudit: this.settings.buttonTexts?.audit || 'Audit'
        };

        Object.entries(btns).forEach(([id, text]) => {
            const btn = document.getElementById(id);
            const span = btn?.querySelector('.btn-text');
            if (span) span.textContent = text;
        });
    }

    setupFullscreen() {
        document.getElementById('fullscreenToggle')?.addEventListener('click', () => {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(() => {});
                document.getElementById('fullscreenToggle')!.innerHTML = '<i class="fas fa-compress"></i>';
            } else {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                    document.getElementById('fullscreenToggle')!.innerHTML = '<i class="fas fa-expand"></i>';
                }
            }
        });
    }

    setupUpdateChecker() {
        const icon = document.getElementById('updateIcon');
        icon?.addEventListener('click', () => {
            icon.classList.add('checking');
            this.showToast('Checking offline database integrity...', 'info');
            setTimeout(() => {
                icon.classList.remove('checking');
                this.showToast('Offline System Verified. All components 100% operational.', 'success');
            }, 1200);
        });
    }

    setupTimeFilters() {
        const filterGroups = ['register', 'sales', 'inventory', 'deduct', 'review', 'audit'];
        const periods = ['daily', 'weekly', 'monthly', 'quarterly', 'semiannual', 'yearly'];

        filterGroups.forEach(group => {
            periods.forEach(period => {
                const btn = document.querySelector(`.${group}-time-filter[data-period="${period}"]`);
                btn?.addEventListener('click', () => {
                    this.currentTimeFilters[group] = period;
                    document.querySelectorAll(`.${group}-time-filter`).forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                    this.refreshActivePage();
                });
            });

            const startInp = document.getElementById(`${group}StartDate`) as HTMLInputElement;
            const endInp = document.getElementById(`${group}EndDate`) as HTMLInputElement;
            if (startInp && endInp) {
                const applyCustom = () => {
                    if (startInp.value && endInp.value) {
                        this.currentTimeFilters[group] = 'custom';
                        this.currentTimeFilters[`${group}Start`] = startInp.value;
                        this.currentTimeFilters[`${group}End`] = endInp.value;
                        this.refreshActivePage();
                    }
                };
                startInp.addEventListener('change', applyCustom);
                endInp.addEventListener('change', applyCustom);
            }
        });
    }

    getFilteredDateRange(group: string) {
        const period = this.currentTimeFilters[group] || 'all';
        const now = new Date();
        let start = new Date(0);
        let end = new Date(now.getTime() + 86400000);

        if (period === 'daily') {
            start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        } else if (period === 'weekly') {
            start = new Date(now.getTime() - 7 * 86400000);
        } else if (period === 'monthly') {
            start = new Date(now.getTime() - 30 * 86400000);
        } else if (period === 'quarterly') {
            start = new Date(now.getTime() - 90 * 86400000);
        } else if (period === 'semiannual') {
            start = new Date(now.getTime() - 180 * 86400000);
        } else if (period === 'yearly') {
            start = new Date(now.getTime() - 365 * 86400000);
        } else if (period === 'custom') {
            start = new Date(this.currentTimeFilters[`${group}Start`] || 0);
            end = new Date(this.currentTimeFilters[`${group}End`] || now);
        }

        return { start, end };
    }

    refreshActivePage() {
        const active = document.querySelector('.full-screen-mode.active');
        if (!active) return;
        if (active.id === 'stockInventoryPage') this.renderTable();
        else if (active.id === 'reviewPage') this.updateReviewDashboard();
        else if (active.id === 'auditPage') {
            this.renderAuditTable();
            this.updateAuditSummary();
        } else if (active.id === 'reduceStockPage') this.renderDeductionHistory();
        else if (active.id === 'salesPage') this.renderSalesHistory();
    }

    setupEventListeners() {
        // Login button
        document.getElementById('loginBtn')?.addEventListener('click', () => this.handleLogin());

        // Notifications
        document.getElementById('criticalCounter')?.addEventListener('click', () => this.openNotificationPanel('critical'));
        document.getElementById('warningCounter')?.addEventListener('click', () => this.openNotificationPanel('warning'));
        document.getElementById('infoCounter')?.addEventListener('click', () => this.openNotificationPanel('info'));
        document.getElementById('closeNotificationPanelBtn')?.addEventListener('click', () => this.closeNotificationPanel());

        // Top navigation links
        document.getElementById('navRegisterStock')?.addEventListener('click', () => this.openPage('registerStockPage'));
        document.getElementById('navSales')?.addEventListener('click', () => this.openPage('salesPage'));
        document.getElementById('navCurrentStock')?.addEventListener('click', () => this.openPage('stockInventoryPage'));
        document.getElementById('navReduceStock')?.addEventListener('click', () => this.openPage('reduceStockPage'));
        document.getElementById('navReview')?.addEventListener('click', () => this.openPage('reviewPage'));
        document.getElementById('navAudit')?.addEventListener('click', () => this.openPage('auditPage'));

        // Close page buttons
        document.querySelectorAll('.close-full-screen').forEach(btn => {
            btn.addEventListener('click', () => {
                const closeTarget = (btn as HTMLElement).dataset.close;
                if (closeTarget) {
                    document.getElementById(closeTarget)?.classList.remove('active');
                } else {
                    btn.closest('.full-screen-mode')?.classList.remove('active');
                    btn.closest('.settings-panel')?.classList.remove('active');
                    btn.closest('.share-modal')?.classList.remove('active');
                }
            });
        });

        // Dashboard card clicks
        document.querySelectorAll('.dashboard-card').forEach(card => {
            card.addEventListener('click', () => {
                const page = (card as HTMLElement).dataset.page;
                const filter = (card as HTMLElement).dataset.filter || null;
                if (page) this.openPage(page, filter);
            });
        });

        // Forms
        document.getElementById('stockForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveItem();
        });
        document.getElementById('clearForm')?.addEventListener('click', () => this.clearRegisterForm());

        document.getElementById('salesForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.processSale();
        });
        document.getElementById('addSalesRow')?.addEventListener('click', () => this.addSalesRow());
        document.getElementById('clearSalesForm')?.addEventListener('click', () => this.clearSalesForm());

        document.getElementById('reduceStockForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.reduceStock();
        });
        document.getElementById('clearReduceForm')?.addEventListener('click', () => this.clearReduceForm());

        // Inventory filters & sorting
        document.getElementById('searchInput')?.addEventListener('input', () => this.renderTable());
        document.getElementById('categoryFilter')?.addEventListener('change', () => this.renderTable());
        document.getElementById('branchFilter')?.addEventListener('change', () => this.renderTable());
        document.getElementById('statusFilter')?.addEventListener('change', () => this.renderTable());
        document.getElementById('inventorySortSelect')?.addEventListener('change', (e) => {
            this.currentSort.inventory = (e.target as HTMLSelectElement).value;
            this.renderTable();
        });
        document.getElementById('clearFilters')?.addEventListener('click', () => {
            (document.getElementById('searchInput') as HTMLInputElement).value = '';
            (document.getElementById('categoryFilter') as HTMLSelectElement).value = '';
            (document.getElementById('branchFilter') as HTMLSelectElement).value = '';
            (document.getElementById('statusFilter') as HTMLSelectElement).value = '';
            (document.getElementById('inventorySortSelect') as HTMLSelectElement).value = 'default';
            this.currentSort.inventory = 'default';
            this.renderTable();
        });

        document.getElementById('balanceVerificationBtn')?.addEventListener('click', () => this.verifyAllBalances());

        // Settings
        document.getElementById('settingsIcon')?.addEventListener('click', () => {
            if (this.currentUserType !== 'admin') {
                this.showToast('Administrator access required for Settings', 'warning');
                return;
            }
            this.loadSettings();
            document.getElementById('settingsPanel')?.classList.add('active');
        });
        document.getElementById('closeSettings')?.addEventListener('click', () => {
            document.getElementById('settingsPanel')?.classList.remove('active');
        });
        document.getElementById('saveSettings')?.addEventListener('click', () => this.saveSettings());
        document.getElementById('backupData')?.addEventListener('click', () => this.backupData());
        document.getElementById('restoreData')?.addEventListener('click', () => this.restoreData());
        document.getElementById('clearAllData')?.addEventListener('click', () => this.clearAllData());

        // Share modal
        document.getElementById('shareIcon')?.addEventListener('click', () => this.openShareModal());
        document.getElementById('closeShareModal')?.addEventListener('click', () => this.closeShareModal());
        document.getElementById('shareMasterCheckbox')?.addEventListener('change', (e) => {
            this.toggleSelectAllShares((e.target as HTMLInputElement).checked);
        });
        document.getElementById('shareSelectAllBtn')?.addEventListener('click', () => this.toggleSelectAllShares(true));
        document.getElementById('shareClearAllBtn')?.addEventListener('click', () => this.toggleSelectAllShares(false));
        document.getElementById('shareSearchInput')?.addEventListener('input', () => this.renderShareTable());
        document.getElementById('shareCategoryFilter')?.addEventListener('change', () => this.renderShareTable());
        document.getElementById('shareStatusFilter')?.addEventListener('change', () => this.renderShareTable());
        document.getElementById('shareBranchFilter')?.addEventListener('change', () => this.renderShareTable());
        document.getElementById('shareSortSelect')?.addEventListener('change', (e) => {
            this.currentSort.share = (e.target as HTMLSelectElement).value;
            this.renderShareTable();
        });
        document.getElementById('shareTelegramBtn')?.addEventListener('click', () => this.shareToTelegram());
        document.getElementById('shareCopyPreviewBtn')?.addEventListener('click', () => this.copySharePreview());
        document.getElementById('shareExportBtn')?.addEventListener('click', () => this.exportSelectedItems());

        // Audit page actions
        document.getElementById('searchAudit')?.addEventListener('input', () => this.renderAuditTable());
        document.getElementById('auditTypeFilter')?.addEventListener('change', () => this.renderAuditTable());
        document.getElementById('auditDateFilter')?.addEventListener('change', () => this.renderAuditTable());
        document.getElementById('toggleAuditDetailBtn')?.addEventListener('click', () => {
            document.getElementById('auditSummaryDetail')?.classList.toggle('hidden-detail');
        });
        document.getElementById('exportAuditReport')?.addEventListener('click', () => {
            this.exportData('excel');
        });

        // Detail toggles on review page
        document.getElementById('demandForecastToggleBtn')?.addEventListener('click', () => {
            document.getElementById('demandForecastDetail')?.classList.toggle('hidden-detail');
        });
        document.getElementById('reorderRecommendationsToggleBtn')?.addEventListener('click', () => {
            document.getElementById('reorderDetail')?.classList.toggle('hidden-detail');
        });
        document.getElementById('totalLossDetailBtn')?.addEventListener('click', () => {
            this.showTotalLossModal();
        });

        // Auto fill on typing generic name
        document.getElementById('itemName')?.addEventListener('input', () => {
            const val = (document.getElementById('itemName') as HTMLInputElement).value.trim();
            if (!val || this.isEditing) return;
            const existing = this.stockItems.find(i => i.name.toLowerCase() === val.toLowerCase());
            if (existing) {
                (document.getElementById('brandName') as HTMLInputElement).value = existing.brandName || '';
                (document.getElementById('category') as HTMLInputElement).value = existing.category || '';
                (document.getElementById('itemType') as HTMLInputElement).value = existing.type || '';
                (document.getElementById('baseUnit') as HTMLInputElement).value = existing.baseUnit || '';
                (document.getElementById('registeredUnit') as HTMLInputElement).value = existing.registeredUnit || '';
                (document.getElementById('displayUnit') as HTMLInputElement).value = existing.displayUnit || '';
                (document.getElementById('registeredToBaseFactor') as HTMLInputElement).value = existing.registeredToBaseFactor || 100;
                (document.getElementById('displayToBaseFactor') as HTMLInputElement).value = existing.displayToBaseFactor || 10;
                (document.getElementById('purchasePricePerDisplay') as HTMLInputElement).value = existing.purchasePricePerDisplay || 50;
                (document.getElementById('markup') as HTMLInputElement).value = existing.markup || 50;
                (document.getElementById('sellingPricePerDisplay') as HTMLInputElement).value = existing.sellingPricePerDisplay || 75;
                document.getElementById('qtyDisplay')?.dispatchEvent(new Event('input'));
                this.showToast('Auto-filled from existing medication record', 'info');
            }
        });
    }

    escapeHtml(str: string): string {
        if (!str) return '';
        return str.replace(/[&<>'"]/g, tag => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
        }[tag] || tag));
    }
}

// Instantiate globally when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        (window as any).ultraStock = new UltraStockSystem();
    });
} else {
    (window as any).ultraStock = new UltraStockSystem();
}
