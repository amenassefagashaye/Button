import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import './stock-system.ts';

createRoot(document.getElementById('root')!).render(<App />);
